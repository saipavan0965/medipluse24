import React, { useState } from 'react';
import { useCart } from '../../context/CartContext';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, ShieldCheck, Truck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, onProceedToCheckout, onContinueShopping }) => {
  const { cart, removeFromCart, updateQuantity, clearCart, subtotal, deliveryCharge, discountAmount, totalAmount, appliedCoupon, applyCoupon, removeCoupon } = useCart();
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState('');

  if (!isOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    if (!couponCode.trim()) return;

    let percent = 15;
    if (couponCode.toUpperCase() === 'MONSOON20') percent = 20;
    if (couponCode.toUpperCase() === 'DEVICES10') percent = 10;

    const success = applyCoupon(couponCode, percent);
    if (!success) {
      setCouponError('Invalid code. Try MONSOON20 or WELCOME15');
    } else {
      setCouponCode('');
    }
  };

  const freeShippingThreshold = 99;
  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-sm flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-200">
        
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">Your Cart ({cart.length} Items)</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress */}
        <div className="bg-teal-50 px-6 py-2.5 border-b border-teal-100">
          <div className="flex items-center justify-between text-[11px] font-semibold text-teal-900 mb-1">
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-teal-600" />
              {subtotal >= freeShippingThreshold ? 'Congratulations! FREE Delivery Unlocked!' : `Add ₹${(freeShippingThreshold - subtotal).toFixed(2)} more for FREE Standard Delivery`}
            </span>
            <span>{progressPercent}%</span>
          </div>
          <div className="w-full bg-teal-200/60 rounded-full h-1.5 overflow-hidden">
            <div className="bg-teal-600 h-full transition-all duration-300" style={{ width: `${progressPercent}%` }}></div>
          </div>
        </div>

        {/* Cart Item List */}
        <div className="p-6 flex-1 overflow-y-auto space-y-4 divide-y divide-slate-100">
          {cart.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">Your cart is currently empty</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">Search or browse our medicine catalogue to add items to your cart.</p>
              <button
                onClick={() => {
                  onClose();
                  onContinueShopping();
                }}
                className="mt-2 py-2 px-4 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition"
              >
                Shop Medicines Now
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="pt-4 first:pt-0 flex gap-3">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-16 h-16 object-contain bg-slate-50 rounded-xl p-2 border border-slate-100 shrink-0"
                />

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{item.name}</h4>
                      <button
                        onClick={() => removeFromCart(item.productId)}
                        className="text-slate-400 hover:text-red-600 p-1"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-400">{item.brand}</p>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
                      <button
                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                        className="p-1 bg-white rounded text-slate-600 hover:bg-slate-50"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-bold text-slate-900">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                        className="p-1 bg-white rounded text-slate-600 hover:bg-slate-50"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="text-xs font-bold text-slate-900">
                      ₹{(item.finalPrice * item.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {cart.length > 0 && (
          <div className="p-6 bg-slate-50 border-t border-slate-100 space-y-3">
            
            {/* Coupon Code Section */}
            {appliedCoupon ? (
              <div className="flex items-center justify-between bg-teal-100/60 p-2.5 rounded-xl border border-teal-200 text-xs">
                <span className="flex items-center gap-1.5 font-bold text-teal-800">
                  <Tag className="w-4 h-4 text-teal-600" /> Coupon '{appliedCoupon}' Applied ({discountAmount > 0 ? `Saved ₹${discountAmount}` : ''})
                </span>
                <button onClick={removeCoupon} className="text-red-600 font-bold hover:underline">Remove</button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Coupon code (e.g. MONSOON20)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 bg-white text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 uppercase"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl"
                >
                  Apply
                </button>
              </form>
            )}
            {couponError && <p className="text-[11px] text-red-600">{couponError}</p>}

            {/* Calculations Breakdown */}
            <div className="space-y-1 text-xs text-slate-600 pt-1">
              <div className="flex justify-between"><span>Subtotal:</span><span>₹{subtotal.toFixed(2)}</span></div>
              {discountAmount > 0 && <div className="flex justify-between text-teal-700"><span>Discount:</span><span>-₹{discountAmount.toFixed(2)}</span></div>}
              <div className="flex justify-between"><span>Estimated Delivery:</span><span>{deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}</span></div>
              <div className="flex justify-between text-slate-900 font-extrabold text-sm pt-2 border-t border-slate-200">
                <span>Total Amount:</span>
                <span className="text-teal-700">₹{totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-3 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg shadow-teal-500/20 transition flex items-center justify-center gap-2"
            >
              Proceed to Checkout <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
