import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { DataProvider, useData } from './context/DataContext';

import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { CartDrawer } from './components/customer/CartDrawer';
import { MedicineDetailsModal } from './components/customer/MedicineDetailsModal';
import { CheckoutModal } from './components/customer/CheckoutModal';

import { HomePage } from './pages/HomePage';
import { MedicinesPage } from './pages/MedicinesPage';
import { ProductsPage } from './pages/ProductsPage';
import { OffersPage } from './pages/OffersPage';
import { HealthTipsPage } from './pages/HealthTipsPage';
import { SeasonalPage } from './pages/SeasonalPage';
import { OrdersPage } from './pages/OrdersPage';
import { ProfilePage } from './pages/ProfilePage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { AuthPage } from './pages/AuthPage';

import { AdminSidebar } from './components/admin/AdminSidebar';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { InventoryPage } from './pages/admin/InventoryPage';
import { ExpiryPage } from './pages/admin/ExpiryPage';
import { ForecastPage } from './pages/admin/ForecastPage';
import { POSPage } from './pages/admin/POSPage';
import { OrdersAdminPage } from './pages/admin/OrdersAdminPage';
import { SuppliersPage } from './pages/admin/SuppliersPage';
import { PurchaseOrdersPage } from './pages/admin/PurchaseOrdersPage';
import { ContentAdminPage } from './pages/admin/ContentAdminPage';
import { ReportsPage } from './pages/admin/ReportsPage';
import { AIAssistantPage } from './pages/admin/AIAssistantPage';

import { Medicine, HealthcareProduct, Order } from './types';
import { Pill, Search as SearchIcon, ShoppingBag, Truck, User as UserIcon, LayoutDashboard, RefreshCw, Bot, ShoppingCart } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { role, setRole } = useAuth();
  const { medicines, products, offers, healthTips, activeSeason, setActiveSeason, orders } = useData();

  const [currentPage, setCurrentPage] = useState<string>('home');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchCategory, setSearchCategory] = useState<string>('ALL');

  // Modals
  const [authOpen, setAuthOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);

  const handleNavigate = (pageWithQuery: string) => {
    if (pageWithQuery.includes('?')) {
      const [page, queryStr] = pageWithQuery.split('?');
      const params = new URLSearchParams(queryStr);
      if (params.has('q')) setSearchQuery(params.get('q') || '');
      if (params.has('category')) setSearchCategory(params.get('category') || 'ALL');
      setCurrentPage(page);
    } else {
      setSearchQuery('');
      setSearchCategory('ALL');
      setCurrentPage(pageWithQuery);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewMedicine = (med: Medicine) => {
    setSelectedMedicine(med);
  };

  const handleBuyNow = (med: Medicine) => {
    setSelectedMedicine(med);
  };

  const handleBuyNowProduct = (prod: HealthcareProduct) => {
    setCartOpen(true);
  };

  const isAdminView = role === 'ADMIN' && currentPage.startsWith('admin-');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between selection:bg-teal-500 selection:text-white font-sans text-slate-800">
      
      {/* Admin View Layout */}
      {isAdminView ? (
        <div className="flex min-h-screen bg-slate-100">
          <AdminSidebar
            currentTab={currentPage}
            onSelectTab={handleNavigate}
            onSwitchToCustomer={() => {
              setRole('CUSTOMER');
              handleNavigate('home');
            }}
          />

          <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto space-y-6 pb-20 md:pb-8">
            {currentPage === 'admin-dashboard' && <AdminDashboard onSelectTab={handleNavigate} />}
            {currentPage === 'admin-inventory' && <InventoryPage />}
            {currentPage === 'admin-pos' && <POSPage />}
            {currentPage === 'admin-orders' && <OrdersAdminPage />}
            {currentPage === 'admin-forecast' && <ForecastPage />}
            {currentPage === 'admin-reorder' && <ForecastPage />}
            {currentPage === 'admin-expiry' && <ExpiryPage />}
            {currentPage === 'admin-suppliers' && <SuppliersPage />}
            {currentPage === 'admin-pos-orders' && <PurchaseOrdersPage />}
            {currentPage === 'admin-products' && <InventoryPage />}
            {currentPage === 'admin-offers' && <ContentAdminPage />}
            {currentPage === 'admin-subscribers' && <ContentAdminPage />}
            {currentPage === 'admin-reports' && <ReportsPage />}
            {currentPage === 'admin-ai-assistant' && <AIAssistantPage />}
          </main>
        </div>
      ) : (
        /* Customer Portal Layout */
        <>
          <Header
            onNavigate={handleNavigate}
            currentPage={currentPage}
            onOpenAuth={() => setAuthOpen(true)}
            onOpenCart={() => setCartOpen(true)}
          />

          <main className="flex-1 pb-16 md:pb-0">
            {currentPage === 'home' && (
              <HomePage
                medicines={medicines}
                products={products}
                offers={offers}
                healthTips={healthTips}
                activeSeason={activeSeason}
                onSeasonChange={setActiveSeason}
                onNavigate={handleNavigate}
                onViewMedicine={handleViewMedicine}
                onBuyNow={handleBuyNow}
              />
            )}

            {currentPage === 'medicines' && (
              <MedicinesPage
                medicines={medicines}
                initialQuery={searchQuery}
                initialCategory={searchCategory}
                onViewDetails={handleViewMedicine}
                onBuyNow={handleBuyNow}
              />
            )}

            {currentPage === 'products' && (
              <ProductsPage
                products={products}
                onBuyNowProduct={handleBuyNowProduct}
              />
            )}

            {currentPage === 'offers' && (
              <OffersPage
                offers={offers}
                onNavigate={handleNavigate}
              />
            )}

            {currentPage === 'tips' && (
              <HealthTipsPage tips={healthTips} />
            )}

            {currentPage === 'seasonal' && (
              <SeasonalPage
                medicines={medicines}
                activeSeason={activeSeason}
                onSeasonChange={setActiveSeason}
                onViewMedicine={handleViewMedicine}
                onBuyNow={handleBuyNow}
              />
            )}

            {currentPage === 'orders' && (
              <OrdersPage orders={orders} />
            )}

            {currentPage === 'profile' && (
              <ProfilePage />
            )}

            {currentPage === 'about' && (
              <AboutPage />
            )}

            {currentPage === 'contact' && (
              <ContactPage />
            )}
          </main>

          <Footer onNavigate={handleNavigate} />
        </>
      )}

      {/* CUSTOMER MOBILE NAVIGATION BAR (Requirement 41) */}
      {!isAdminView ? (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-3 py-2 flex items-center justify-around text-center shadow-lg">
          <button
            onClick={() => handleNavigate('home')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'home' ? 'text-teal-600 font-bold' : 'text-slate-500'}`}
          >
            <Pill className="w-5 h-5" /> Home
          </button>

          <button
            onClick={() => handleNavigate('medicines')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'medicines' ? 'text-teal-600 font-bold' : 'text-slate-500'}`}
          >
            <SearchIcon className="w-5 h-5" /> Search
          </button>

          <button
            onClick={() => setCartOpen(true)}
            className="flex flex-col items-center gap-0.5 text-[10px] font-semibold text-slate-500 relative"
          >
            <ShoppingBag className="w-5 h-5" /> Cart
          </button>

          <button
            onClick={() => handleNavigate('orders')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'orders' ? 'text-teal-600 font-bold' : 'text-slate-500'}`}
          >
            <Truck className="w-5 h-5" /> Orders
          </button>

          <button
            onClick={() => handleNavigate('profile')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'profile' ? 'text-teal-600 font-bold' : 'text-slate-500'}`}
          >
            <UserIcon className="w-5 h-5" /> Profile
          </button>
        </div>
      ) : (
        /* ADMIN MOBILE NAVIGATION BAR (Requirement 41) */
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900 text-white border-t border-slate-800 px-3 py-2 flex items-center justify-around text-center shadow-lg">
          <button
            onClick={() => handleNavigate('admin-dashboard')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'admin-dashboard' ? 'text-teal-400 font-bold' : 'text-slate-400'}`}
          >
            <LayoutDashboard className="w-5 h-5" /> Dashboard
          </button>

          <button
            onClick={() => handleNavigate('admin-inventory')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'admin-inventory' ? 'text-teal-400 font-bold' : 'text-slate-400'}`}
          >
            <Pill className="w-5 h-5" /> Inventory
          </button>

          <button
            onClick={() => handleNavigate('admin-pos')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'admin-pos' ? 'text-teal-400 font-bold' : 'text-slate-400'}`}
          >
            <ShoppingCart className="w-5 h-5" /> POS
          </button>

          <button
            onClick={() => handleNavigate('admin-orders')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'admin-orders' ? 'text-teal-400 font-bold' : 'text-slate-400'}`}
          >
            <Truck className="w-5 h-5" /> Orders
          </button>

          <button
            onClick={() => handleNavigate('admin-ai-assistant')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-semibold ${currentPage === 'admin-ai-assistant' ? 'text-teal-400 font-bold' : 'text-slate-400'}`}
          >
            <Bot className="w-5 h-5 text-teal-400" /> AI Assistant
          </button>
        </div>
      )}

      {/* Global Drawers & Modals */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        onProceedToCheckout={() => {
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
        onContinueShopping={() => handleNavigate('medicines')}
      />

      <MedicineDetailsModal
        medicine={selectedMedicine}
        onClose={() => setSelectedMedicine(null)}
        onProceedToCheckout={() => setCheckoutOpen(true)}
      />

      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onOrderComplete={(order) => {
          handleNavigate('orders');
        }}
      />

      {authOpen && (
        <AuthPage
          onClose={() => setAuthOpen(false)}
          onSuccess={() => {}}
        />
      )}

    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <DataProvider>
        <CartProvider>
          <MainAppContent />
        </CartProvider>
      </DataProvider>
    </AuthProvider>
  );
};

export default App;
