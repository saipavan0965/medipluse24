import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { MedicineModel } from '../models/Medicine.js';
import { OrderModel } from '../models/Order.js';
import { INITIAL_MEDICINES, INITIAL_ORDERS } from '../../src/services/mockData.js';

dotenv.config();

const seedDB = async () => {
  try {
    const connStr = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/medipulse_ai';
    await mongoose.connect(connStr);
    console.log('[Seed]: Connected to MongoDB');

    await MedicineModel.deleteMany({});
    await OrderModel.deleteMany({});

    await MedicineModel.insertMany(INITIAL_MEDICINES);
    await OrderModel.insertMany(INITIAL_ORDERS);

    console.log('[Seed Success]: Successfully seeded 15+ demo medicines and initial customer orders into MongoDB.');
    process.exit(0);
  } catch (error) {
    console.error('[Seed Error]:', error.message);
    process.exit(1);
  }
};

seedDB();
