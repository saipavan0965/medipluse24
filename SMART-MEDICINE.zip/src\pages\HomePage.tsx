import React, { useState } from 'react';
import { Medicine, HealthcareProduct, HealthTip, Offer } from '../types';
import { MedicineCard } from '../components/customer/MedicineCard';
import { Search, Sparkles, ShieldCheck, Truck, Clock, Award, Sun, ArrowRight, Tag, HeartPulse, Pill, CheckCircle2, ChevronRight } from 'lucide-react';

interface HomePageProps {
  medicines: Medicine[];
  products: HealthcareProduct[];
  offers: Offer[];
  healthTips: HealthTip[];
  activeSeason: string;
  onSeasonChange: (season: string) => void;
  onNavigate: (page: string) => void;
  onViewMedicine: (med: Medicine) => void;
  onBuyNow: (med: Medicine) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  medicines,
  products,
  offers,
  healthTips,
  activeSeason,
  onSeasonChange,
  onNavigate,
  onViewMedicine,
  onBuyNow
}) => {
  const [heroSearch, setHeroSearch] = useState('');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearch.trim()) {
      onNavigate(`medicines?q=${encodeURIComponent(heroSearch)}`);
    }
  };

  const fallbackImage = 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80';

  const categories = [
    { name: 'Fever & Pain Relief', icon: Pill, color: 'bg-rose-50 text-rose-700 border-rose-200' },
    { name: 'Cold & Cough', icon: Pill, color: 'bg-blue-50 text-blue-700 border-blue-200' },
    { name: 'Respiratory Care', icon: HeartPulse, color: 'bg-teal-50 text-teal-700 border-teal-200' },
    { name: 'Diabetes Care', icon: Pill, color: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
    { name: 'Heart Care', icon: HeartPulse, color: 'bg-purple-50 text-purple-700 border-purple-200' },
    { name: 'Vitamins & Supplements', icon: Pill, color: 'bg-amber-50 text-amber-700 border-amber-200' },
    { name: 'First Aid', icon: HeartPulse, color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  ];

  return (
    <div className="space-y-16 pb-16">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white pt-16 pb-20 rounded-b-3xl shadow-xl">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-semibold">
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span>Next-Gen Smart Medicine Supply Platform</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight font-display">
                Smart Medicine Supply. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-emerald-300 to-cyan-400">
                  Healthier Tomorrow.
                </span>
              </h1>

              <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
                Order genuine medicines and healthcare devices while our intelligent system optimizes stock replenishment, monitors batch expiry, and prevents medicine shortages.
              </p>

              <form onSubmit={handleHeroSearch} className="max-w-xl mx-auto lg:mx-0 relative pt-2">
                <div className="relative flex items-center">
                  <input
                    type="text"
                    placeholder="Search medicines, categories, brands, symptoms..."
                    value={heroSearch}
                    onChange={(e) => setHeroSearch(e.target.value)}
                    className="w-full bg-white text-slate-900 text-sm placeholder-slate-400 pl-11 pr-28 py-3.5 rounded-2xl shadow-xl focus:outline-none focus:ring-4 focus:ring-teal-500/30"
                  />
                  <Search className="w-5 h-5 text-slate-400 absolute left-3.5" />
                  <button
                    type="submit"
                    className="absolute right-2 px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl transition shadow-md"
                  >
                    Search
                  </button>
                </div>
              </form>

              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => onNavigate('medicines')}
                  className="px-6 py-3.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-teal-500/30 transition flex items-center gap-2"
                >
                  <Pill className="w-4 h-4" /> Shop Medicines
                </button>

                <button
                  onClick={() => onNavigate('products')}
                  className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl border border-slate-700 transition flex items-center gap-2"
                >
                  <HeartPulse className="w-4 h-4 text-teal-400" /> Healthcare Devices
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md rounded-3xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-800/80 p-2 backdrop-blur-md">
                <img
                  src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80"
                  onError={(e) => { e.currentTarget.src = fallbackImage; }}
                  alt="MediPulse AI Pharmacy"
                  className="w-full h-80 object-cover rounded-2xl"
                />
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { title: 'Genuine Medicines', desc: '100% Certified Supply', icon: ShieldCheck, color: 'text-teal-600 bg-teal-50 border-teal-100' },
            { title: 'Express Delivery', desc: '24-48 Hours Doorstep', icon: Truck, color: 'text-blue-600 bg-blue-50 border-blue-100' },
            { title: 'Cash on Delivery', desc: 'Pay Cash at Door', icon: Award, color: 'text-emerald-600 bg-emerald-50 border-emerald-100' },
            { title: 'Secure Payments', desc: 'UPI, Cards & Banking', icon: CheckCircle2, color: 'text-indigo-600 bg-indigo-50 border-indigo-100' },
            { title: 'Smart Inventory', desc: 'Zero Shortage AI', icon: Sparkles, color: 'text-purple-600 bg-purple-50 border-purple-100' },
            { title: '24/7 Support', desc: 'Expert Assistance', icon: Clock, color: 'text-amber-600 bg-amber-50 border-amber-100' },
          ].map((f, idx) => {
            const Icon = f.icon;
            return (
              <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition text-center space-y-2">
                <div className={`w-10 h-10 rounded-xl mx-auto flex items-center justify-center border ${f.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">{f.title}</h4>
                <p className="text-[10px] text-slate-400 font-medium">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Featured Medicines */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Popular & Essential Medicines</h2>
            <p className="text-xs text-slate-500">Real-time available stock with verified pricing</p>
          </div>
          <button
            onClick={() => onNavigate('medicines')}
            className="text-teal-700 hover:text-teal-800 text-xs font-bold flex items-center gap-1"
          >
            Browse Catalogue <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {medicines.slice(0, 8).map((med) => (
            <MedicineCard
              key={med.id}
              medicine={med}
              onViewDetails={onViewMedicine}
              onBuyNow={onBuyNow}
            />
          ))}
        </div>
      </section>

      {/* Educational Health Tips Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Health Tips & Wellness Articles</h2>
            <p className="text-xs text-slate-500">General educational healthcare content prepared by advisory team</p>
          </div>
          <button onClick={() => onNavigate('tips')} className="text-teal-700 hover:text-teal-800 text-xs font-bold flex items-center gap-1">
            Read Articles <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {healthTips.slice(0, 3).map((tip) => (
            <div key={tip.id} className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition overflow-hidden flex flex-col justify-between">
              <img
                src={tip.image}
                onError={(e) => { e.currentTarget.src = fallbackImage; }}
                alt={tip.title}
                className="h-44 w-full object-cover"
              />
              <div className="p-5 space-y-2">
                <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-100">{tip.category}</span>
                <h3 className="text-sm font-bold text-slate-900 line-clamp-2">{tip.title}</h3>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{tip.shortDescription}</p>
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{tip.readTime}</span>
                  <button onClick={() => onNavigate('tips')} className="text-teal-700 font-bold hover:underline">Read Article</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
