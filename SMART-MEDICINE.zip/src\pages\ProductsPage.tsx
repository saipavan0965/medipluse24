import React from 'react';
import { HealthcareProduct } from '../types';
import { useCart } from '../context/CartContext';
import { HeartPulse, Star, ShoppingBag, Zap, ShieldCheck } from 'lucide-react';

interface ProductsPageProps {
  products: HealthcareProduct[];
  onBuyNowProduct: (product: HealthcareProduct) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({ products, onBuyNowProduct }) => {
  const { addToCart } = useCart();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold mb-2">
          <HeartPulse className="w-4 h-4 text-teal-600" /> Healthcare Devices & Personal Care
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Health Monitoring Devices & Equipment</h1>
        <p className="text-xs text-slate-500">Certified blood pressure monitors, glucometers, thermometers, and medical accessories</p>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((prod) => (
          <div key={prod.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group">
            
            <div className="bg-slate-50 p-6 border-b border-slate-100 flex items-center justify-center min-h-[220px] relative">
              <span className="absolute top-3 left-3 bg-red-500 text-white text-[11px] font-extrabold px-2 py-0.5 rounded">
                {prod.discountPercentage}% OFF
              </span>
              {prod.warranty && (
                <span className="absolute top-3 right-3 bg-teal-100 text-teal-800 text-[10px] font-bold px-2 py-0.5 rounded border border-teal-200">
                  {prod.warranty}
                </span>
              )}
              <img src={prod.image} alt={prod.name} className="h-44 object-contain group-hover:scale-105 transition-transform" />
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span className="font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded">{prod.category}</span>
                  <span className="flex items-center gap-1 font-bold text-slate-700">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {prod.rating}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-600 transition">{prod.name}</h3>
                <p className="text-xs text-slate-500 line-clamp-2 mt-2 leading-relaxed">{prod.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 space-y-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-extrabold text-slate-900 font-display">₹{prod.finalPrice.toFixed(2)}</span>
                  <span className="text-xs text-slate-400 line-through">₹{prod.price.toFixed(2)}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => addToCart(prod)}
                    className="py-2.5 px-3 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 border border-teal-200"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" /> Cart
                  </button>

                  <button
                    onClick={() => onBuyNowProduct(prod)}
                    className="py-2.5 px-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Zap className="w-3.5 h-3.5" /> Buy Now
                  </button>
                </div>
              </div>

            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
