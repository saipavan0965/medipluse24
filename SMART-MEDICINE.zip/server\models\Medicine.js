import mongoose from 'mongoose';

const batchSchema = new mongoose.Schema({
  batchNumber: { type: String, required: true },
  expiryDate: { type: String, required: true },
  quantity: { type: Number, default: 0 },
  purchasePrice: { type: Number, default: 0 },
  mrp: { type: Number, default: 0 }
});

const medicineSchema = new mongoose.Schema({
  medicineId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  brand: { type: String, required: true },
  manufacturer: { type: String, required: true },
  category: { type: String, required: true },
  description: { type: String },
  usage: { type: String },
  warnings: { type: String },
  price: { type: Number, required: true },
  discountPercentage: { type: Number, default: 0 },
  finalPrice: { type: Number, required: true },
  stockQuantity: { type: Number, required: true, default: 0 },
  reorderLevel: { type: Number, default: 20 },
  safetyStock: { type: Number, default: 10 },
  batchNumber: { type: String, required: true },
  expiryDate: { type: String, required: true },
  supplier: { type: String, required: true },
  image: { type: String },
  prescriptionRequired: { type: Boolean, default: false },
  rating: { type: Number, default: 4.5 },
  batches: [batchSchema]
}, { timestamps: true });

export const MedicineModel = mongoose.models.Medicine || mongoose.model('Medicine', medicineSchema);
