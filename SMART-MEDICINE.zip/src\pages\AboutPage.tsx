import React from 'react';
import { ShieldCheck, Sparkles, HeartPulse, Cpu, Layers, Award, CheckCircle } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100 text-teal-800 text-xs font-bold">
          <Sparkles className="w-4 h-4 text-teal-600" /> Platform Mission & Vision
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          About <span className="text-teal-600">MediPulse AI</span>
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          MediPulse AI is a smart medicine demand and supply management platform designed to combine pharmacy shopping, inventory visibility, demand forecasting, and healthcare information into one seamless ecosystem.
        </p>
      </div>

      {/* Main Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-900">The Smart Inventory Innovation</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Traditional pharmacy systems suffer from stockout vulnerabilities during seasonal illness spikes or inefficient manual overstocking leading to expired drug losses. MediPulse AI bridges this gap by combining real-time e-commerce demand signals with predictive machine-learning models.
          </p>

          <div className="space-y-2 pt-2">
            {[
              'Predictive Demand Forecasting based on 7/30/90-day sales velocity and seasonal factors.',
              'First-Expiry-First-Out (FEFO) automated batch audit and discount rotation.',
              'Automated Purchase Order drafts generated with 1-click supplier approval.',
              'Conversational Natural-Language AI Inventory Assistant for pharmacy operators.'
            ].map((pt, idx) => (
              <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                <CheckCircle className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>{pt}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden shadow-xl border border-slate-200 bg-slate-900 text-white p-6 space-y-4">
          <img
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80"
            alt="AI Pharmacy Intelligence"
            className="rounded-2xl h-56 w-full object-cover"
          />
          <div>
            <h3 className="font-bold text-sm text-white">Full-Stack Platform Architecture</h3>
            <p className="text-xs text-slate-300 mt-1">Built with React.js, TypeScript, Vite, Tailwind CSS, Recharts, Node.js, Express.js, and MongoDB.</p>
          </div>
        </div>
      </div>

      {/* Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center border border-teal-100">
            <HeartPulse className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Patient-Centric Care</h3>
          <p className="text-xs text-slate-500 leading-relaxed">Guaranteeing genuine medicine availability, express delivery, and transparent pricing for customers.</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
            <Cpu className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">AI Supply Optimization</h3>
          <p className="text-xs text-slate-500 leading-relaxed">Reducing medicine waste, tracking batch expiry risk tiers, and setting dynamic reorder thresholds.</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-100">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">POS & Supplier Integration</h3>
          <p className="text-xs text-slate-500 leading-relaxed">Connecting walk-in billing registers, online orders, and supplier purchase orders seamlessly.</p>
        </div>
      </div>

    </div>
  );
};
