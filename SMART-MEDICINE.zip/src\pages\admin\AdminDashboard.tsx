import React from 'react';
import { useData } from '../../context/DataContext';
import { MetricsOverview } from '../../components/admin/MetricsOverview';
import { DemandChart } from '../../components/admin/DemandChart';
import { ReorderTable } from '../../components/admin/ReorderTable';
import { LayoutDashboard, Sparkles, RefreshCw, AlertTriangle, ShoppingCart, Bot, ArrowRight } from 'lucide-react';

interface AdminDashboardProps {
  onSelectTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectTab }) => {
  const { medicines, orders, sales, expiryRisks, forecasts } = useData();

  return (
    <div className="space-y-8">
      
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold mb-1.5">
            <Sparkles className="w-4 h-4 text-teal-600" /> Executive Operations & AI Supply Console
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Pharmacy Operations Dashboard</h1>
          <p className="text-xs text-slate-500">Real-time inventory levels, AI demand predictions, and order fulfillment</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onSelectTab('admin-pos')}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-sm transition flex items-center gap-1.5"
          >
            <ShoppingCart className="w-4 h-4" /> Open POS Billing Counter
          </button>
          <button
            onClick={() => onSelectTab('admin-ai-assistant')}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-teal-400 text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5"
          >
            <Bot className="w-4 h-4 text-teal-400 animate-pulse" /> Ask AI Assistant
          </button>
        </div>
      </div>

      {/* Metric Widgets Grid */}
      <MetricsOverview
        medicines={medicines}
        orders={orders}
        sales={sales}
        expiryRisks={expiryRisks}
      />

      {/* Quick Alert Bar */}
      {expiryRisks.filter(r => r.riskTier === 'URGENT' || r.riskTier === 'EXPIRED').length > 0 && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-center gap-2 font-semibold">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <span>
              Attention: {expiryRisks.filter(r => r.riskTier === 'URGENT' || r.riskTier === 'EXPIRED').length} batches require immediate FEFO rotation or quarantine write-off.
            </span>
          </div>
          <button
            onClick={() => onSelectTab('admin-expiry')}
            className="px-3 py-1.5 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 transition"
          >
            Audit Expiry Matrix
          </button>
        </div>
      )}

      {/* Analytics Recharts Visualization */}
      <DemandChart
        forecasts={forecasts}
        expiryRisks={expiryRisks}
      />

      {/* AI Re-Order Action Proposals */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">High-Priority Replenishment Recommendations</h2>
          <button
            onClick={() => onSelectTab('admin-reorder')}
            className="text-xs font-bold text-teal-700 hover:underline flex items-center gap-1"
          >
            View All AI Re-Orders <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <ReorderTable forecasts={forecasts} />
      </div>

    </div>
  );
};
