import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectDB } from './config/db.js';
import apiRoutes from './routes/apiRoutes.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Connect DB (with fallback warning if MongoDB is offline)
connectDB();

// API Routes
app.use('/api', apiRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'UP', service: 'MediPulse AI Server', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`[MediPulse AI Backend Server]: Running on http://localhost:${PORT}`);
});
