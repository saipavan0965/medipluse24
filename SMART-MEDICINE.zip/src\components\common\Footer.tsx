import React, { useState } from 'react';
import { HeartPulse, Mail, CheckCircle, ShieldCheck, Truck, Clock, Award, Phone, Send } from 'lucide-react';
import { ApiService } from '../../services/api';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setLoading(true);
    await ApiService.subscribeNewsletter(email);
    setLoading(false);
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Value Highlights Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pb-12 mb-12 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Genuine Medicines</h4>
              <p className="text-[11px] text-slate-400">100% Verified Pharmacy Supply</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Express Delivery</h4>
              <p className="text-[11px] text-slate-400">24-48 Hours Doorstep Delivery</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">24/7 AI Availability</h4>
              <p className="text-[11px] text-slate-400">Smart Stock Replenishment</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Best Offers & COD</h4>
              <p className="text-[11px] text-slate-400">Cash on Delivery & Discounts</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12">
          
          {/* Col 1: Brand & Tagline */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-teal-500 text-white flex items-center justify-center shadow-lg shadow-teal-500/30">
                <HeartPulse className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">MediPulse <span className="text-teal-400">AI</span></span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              MediPulse AI is an intelligent medicine demand and supply management platform combining online pharmacy e-commerce with real-time demand forecasting, stock replenishment, and expiry tracking.
            </p>

            {/* Newsletter Subscription Box */}
            <div className="pt-2">
              <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-2">Stay Updated With MediPulse AI</h5>
              <p className="text-[11px] text-slate-400 mb-3">Subscribe to receive seasonal health tips, medicine availability updates, and special discounts.</p>
              
              {subscribed ? (
                <div className="flex items-center gap-2 p-3 bg-teal-900/40 border border-teal-500/30 rounded-xl text-teal-300 text-xs font-medium">
                  <CheckCircle className="w-4 h-4 text-teal-400 shrink-0" />
                  <span>Thank you! You are now subscribed to MediPulse AI updates.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="email"
                      required
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-800 text-white text-xs placeholder-slate-500 pl-9 pr-3 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-teal-500"
                    />
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2.5 text-xs font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 rounded-xl transition flex items-center gap-1.5 shrink-0"
                  >
                    <span>Subscribe</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-teal-400 pl-2">Quick Links</h4>
            <ul className="space-y-2 text-xs">
              {['home', 'medicines', 'products', 'seasonal', 'offers', 'tips', 'about', 'contact'].map((page) => (
                <li key={page}>
                  <button
                    onClick={() => onNavigate(page)}
                    className="text-slate-400 hover:text-teal-400 transition capitalize flex items-center gap-1"
                  >
                    <span className="text-slate-600">›</span> {page.replace('-', ' ')}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Customer Support */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-teal-400 pl-2">Customer Support</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><button onClick={() => onNavigate('orders')} className="hover:text-teal-400">My Orders & Tracking</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-teal-400">Help Center & FAQ</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-teal-400">Express Delivery Info</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-teal-400">Return & Refund Policy</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-teal-400">24/7 Support Desk</button></li>
            </ul>
          </div>

          {/* Col 4: Contact Info */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-teal-400 pl-2">Contact & Location</h4>
            <div className="space-y-3 text-xs text-slate-400">
              <p className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>+91 1800-425-9000 (Toll-Free)</span>
              </p>
              <p className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>support@medipulse.ai</span>
              </p>
              <p className="text-[11px] leading-relaxed text-slate-400">
                MediPulse AI Health Tower, Phase-4 Technology Park, Bengaluru, Karnataka - 560100
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between text-xs text-slate-400 gap-4">
          <p>© {new Date().getFullYear()} MediPulse AI. All Rights Reserved. Smart Pharmacy & Supply Management.</p>
          <div className="flex items-center space-x-6 text-[11px]">
            <button onClick={() => onNavigate('contact')} className="hover:text-white">Privacy Policy</button>
            <button onClick={() => onNavigate('contact')} className="hover:text-white">Terms & Conditions</button>
            <button onClick={() => onNavigate('about')} className="hover:text-white">Medical Disclaimer</button>
          </div>
        </div>

      </div>
    </footer>
  );
};
