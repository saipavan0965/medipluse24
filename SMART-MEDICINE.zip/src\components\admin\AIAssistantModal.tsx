import React, { useState } from 'react';
import { Medicine, AIChatMessage } from '../../types';
import { processAIAssistantQuery } from '../../services/aiEngine';
import { Bot, Send, Sparkles, User, ShieldAlert, CheckCircle, ArrowRight } from 'lucide-react';

interface AIAssistantModalProps {
  medicines: Medicine[];
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({ medicines }) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: 'Hello! I am **MediPulse AI Assistant**. I analyze your live medicine inventory, sales velocity, batch expiry dates, and supplier lead times.\n\nHow can I help optimize your supply chain today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState('');

  const suggestedPrompts = [
    'Which medicines are low in stock?',
    'Which medicines will expire soon?',
    'What should I reorder this week?',
    'Which category has the highest demand?',
    'How much stock do we currently have?'
  ];

  const handleSend = (textToSend?: string) => {
    const prompt = textToSend || inputPrompt;
    if (!prompt.trim()) return;

    const userMsg: AIChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputPrompt('');

    // Instant AI Response generation using live inventory context
    setTimeout(() => {
      const aiMsg = processAIAssistantQuery(prompt, medicines);
      setMessages(prev => [...prev, aiMsg]);
    }, 400);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col h-[680px]">
      
      {/* Header */}
      <div className="p-4 px-6 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-400 to-teal-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-teal-500/20">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm font-bold flex items-center gap-1.5">
              MediPulse AI Assistant <Sparkles className="w-4 h-4 text-teal-400" />
            </h3>
            <p className="text-[11px] text-teal-300">Natural Language Inventory & Supply Intelligence</p>
          </div>
        </div>

        <div className="bg-slate-800 text-teal-400 text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-700">
          Live Data Sync Active
        </div>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="bg-slate-50 p-3 px-6 border-b border-slate-200 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[11px] font-bold text-slate-500 shrink-0">Quick Queries:</span>
        {suggestedPrompts.map((sp, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(sp)}
            className="px-3 py-1 bg-white hover:bg-teal-50 text-slate-700 hover:text-teal-700 text-[11px] font-semibold rounded-full border border-slate-200 transition shrink-0 shadow-2xs"
          >
            {sp}
          </button>
        ))}
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/50">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 max-w-2xl ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
              msg.sender === 'user' ? 'bg-teal-600 text-white' : 'bg-slate-900 text-teal-400'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`p-4 rounded-2xl text-xs space-y-2 leading-relaxed shadow-sm ${
              msg.sender === 'user'
                ? 'bg-teal-600 text-white font-medium rounded-tr-none'
                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
            }`}>
              <div className="whitespace-pre-line font-sans">
                {msg.text}
              </div>
              <span className={`text-[9px] block text-right font-medium ${msg.sender === 'user' ? 'text-teal-200' : 'text-slate-400'}`}>
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-4 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="Ask AI about inventory, expiring batches, low stock, or purchase orders..."
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            className="flex-1 bg-slate-100 text-xs text-slate-800 placeholder-slate-400 px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
          />
          <button
            type="submit"
            className="px-5 py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5 shrink-0"
          >
            <span>Ask AI</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

    </div>
  );
};
