import React, { useState } from 'react';
import { Medicine } from '../../types';
import { useData } from '../../context/DataContext';
import { Search, ShoppingCart, Plus, Minus, Trash2, CheckCircle2, Printer, Zap } from 'lucide-react';

interface POSInterfaceProps {
  medicines: Medicine[];
}

export const POSInterface: React.FC<POSInterfaceProps> = ({ medicines }) => {
  const { recordPOSTransaction } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [billItems, setBillItems] = useState<{ medicine: Medicine; quantity: number }[]>([]);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [customerName, setCustomerName] = useState<string>('Walk-in Customer');
  const [lastReceipt, setLastReceipt] = useState<any | null>(null);

  const filteredMedicines = medicines.filter(m =>
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.medicineId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToBill = (med: Medicine) => {
    if (med.stockQuantity === 0) return;
    setBillItems(prev => {
      const existing = prev.find(item => item.medicine.id === med.id);
      if (existing) {
        return prev.map(item =>
          item.medicine.id === med.id
            ? { ...item, quantity: Math.min(med.stockQuantity, item.quantity + 1) }
            : item
        );
      }
      return [...prev, { medicine: med, quantity: 1 }];
    });
  };

  const updateBillQty = (medId: string, delta: number) => {
    setBillItems(prev =>
      prev
        .map(item => {
          if (item.medicine.id === medId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: Math.min(item.medicine.stockQuantity, newQty) } : null;
          }
          return item;
        })
        .filter(Boolean) as { medicine: Medicine; quantity: number }[]
    );
  };

  const removeItem = (medId: string) => {
    setBillItems(prev => prev.filter(item => item.medicine.id !== medId));
  };

  const subtotal = billItems.reduce((sum, item) => sum + item.medicine.finalPrice * item.quantity, 0);
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const totalAmount = Math.max(0, subtotal - discountAmount);

  const handleCheckoutSale = () => {
    if (billItems.length === 0) return;

    const formattedItems = billItems.map(item => ({
      medicineId: item.medicine.medicineId || item.medicine.id,
      medicineName: item.medicine.name,
      quantity: item.quantity,
      price: item.medicine.finalPrice,
      subtotal: item.medicine.finalPrice * item.quantity
    }));

    recordPOSTransaction(formattedItems, paymentMethod, customerName);

    setLastReceipt({
      invoiceId: `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      items: formattedItems,
      subtotal,
      discountAmount,
      totalAmount,
      paymentMethod,
      customerName,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });

    setBillItems([]);
    setDiscountPercent(0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Left: Product Lookup & Grid (7 cols) */}
      <div className="lg:col-span-7 space-y-4">
        
        {/* Search Bar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Search medicine name, SKU barcode or brand..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-100 text-xs text-slate-800 placeholder-slate-400 pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>
        </div>

        {/* Medicines Quick Selector Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[600px] overflow-y-auto pr-1">
          {filteredMedicines.map((med) => {
            const isOut = med.stockQuantity === 0;
            return (
              <div
                key={med.id}
                onClick={() => !isOut && addToBill(med)}
                className={`p-3 rounded-2xl border bg-white cursor-pointer transition flex flex-col justify-between ${
                  isOut ? 'opacity-50 cursor-not-allowed border-slate-200' : 'hover:border-teal-500 hover:shadow-md border-slate-200'
                }`}
              >
                <div>
                  <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">{med.category}</span>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1 mt-1">{med.name}</h4>
                  <p className="text-[10px] text-slate-400">{med.brand}</p>
                </div>
                <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2">
                  <span className="text-xs font-extrabold text-slate-900">₹{med.finalPrice.toFixed(2)}</span>
                  <span className={`text-[10px] font-bold ${isOut ? 'text-red-600' : 'text-slate-500'}`}>
                    {isOut ? 'Out of Stock' : `${med.stockQuantity} in stock`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Current Billing Counter Desk (5 cols) */}
      <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
        
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-teal-600" />
              <h3 className="text-sm font-bold text-slate-900">Billing Counter Invoice</h3>
            </div>
            <span className="text-xs text-slate-400 font-semibold">{new Date().toLocaleDateString()}</span>
          </div>

          {/* Customer Name Input */}
          <div className="mt-3">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Customer Name</label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full bg-slate-50 text-xs p-2 rounded-xl border border-slate-200 focus:outline-none"
            />
          </div>

          {/* Bill Items List */}
          <div className="mt-4 space-y-2.5 max-h-[260px] overflow-y-auto divide-y divide-slate-100 pr-1">
            {billItems.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                Click medicines on the left to add to bill register
              </div>
            ) : (
              billItems.map((item) => (
                <div key={item.medicine.id} className="pt-2 flex items-center justify-between text-xs">
                  <div className="flex-1 pr-2">
                    <h5 className="font-bold text-slate-800 line-clamp-1">{item.medicine.name}</h5>
                    <p className="text-[10px] text-slate-400">₹{item.medicine.finalPrice.toFixed(2)} / unit</p>
                  </div>
                  
                  <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
                    <button onClick={() => updateBillQty(item.medicine.id, -1)} className="p-0.5 bg-white rounded text-slate-600">
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-5 text-center font-bold text-slate-900 text-xs">{item.quantity}</span>
                    <button onClick={() => updateBillQty(item.medicine.id, 1)} className="p-0.5 bg-white rounded text-slate-600">
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="w-16 text-right font-bold text-slate-900">
                    ₹{(item.medicine.finalPrice * item.quantity).toFixed(2)}
                  </span>

                  <button onClick={() => removeItem(item.medicine.id)} className="text-slate-400 hover:text-red-600 ml-2">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Bill Summary & Payment Trigger */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Discount %</label>
              <input
                type="number"
                min="0"
                max="50"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(Number(e.target.value))}
                className="w-full bg-slate-50 p-2 rounded-xl border border-slate-200 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Payment Mode</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full bg-slate-50 p-2 rounded-xl border border-slate-200 focus:outline-none font-semibold text-slate-800"
              >
                <option value="Cash">Cash</option>
                <option value="UPI">UPI / QR Code</option>
                <option value="Card">Credit/Debit Card</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl space-y-1 text-xs text-slate-600">
            <div className="flex justify-between"><span>Subtotal:</span><span>₹{subtotal.toFixed(2)}</span></div>
            {discountAmount > 0 && <div className="flex justify-between text-teal-700"><span>Discount ({discountPercent}%):</span><span>-₹{discountAmount.toFixed(2)}</span></div>}
            <div className="flex justify-between font-black text-slate-900 text-sm pt-1 border-t border-slate-200">
              <span>Grand Total:</span>
              <span className="text-teal-700">₹{totalAmount.toFixed(2)}</span>
            </div>
          </div>

          <button
            disabled={billItems.length === 0}
            onClick={handleCheckoutSale}
            className={`w-full py-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              billItems.length === 0
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-teal-600 hover:bg-teal-700 text-white shadow-lg shadow-teal-500/20 active:scale-95'
            }`}
          >
            <Zap className="w-4 h-4" /> Complete Sale & Deduct Stock (₹{totalAmount.toFixed(2)})
          </button>

          {/* Last Receipt Notification */}
          {lastReceipt && (
            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs space-y-1">
              <div className="flex items-center justify-between text-emerald-800 font-bold">
                <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> Sale Complete ({lastReceipt.invoiceId})</span>
                <span>₹{lastReceipt.totalAmount.toFixed(2)}</span>
              </div>
              <p className="text-[11px] text-slate-600">Inventory updated in real-time. Bill ready for printing.</p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
