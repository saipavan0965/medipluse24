import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { BarChart2, Download, Filter, Printer, FileSpreadsheet, CheckCircle2 } from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { medicines, sales, orders, expiryRisks, forecasts, suppliers, purchaseOrders } = useData();

  const [activeReport, setActiveReport] = useState<'inventory' | 'sales' | 'expiry' | 'forecast' | 'suppliers'>('inventory');
  const [downloadMsg, setDownloadMsg] = useState(false);

  const exportCSV = () => {
    let rows: string[][] = [];
    let filename = `MediPulse_${activeReport}_Report.csv`;

    if (activeReport === 'inventory') {
      rows.push(['Medicine ID', 'Name', 'Brand', 'Category', 'Stock Qty', 'Reorder Level', 'Price', 'Expiry Date']);
      medicines.forEach(m => rows.push([m.medicineId, m.name, m.brand, m.category, m.stockQuantity.toString(), m.reorderLevel.toString(), m.finalPrice.toString(), m.expiryDate]));
    } else if (activeReport === 'sales') {
      rows.push(['Invoice ID', 'Date', 'Customer', 'Items Count', 'Payment Method', 'Total Amount']);
      sales.forEach(s => rows.push([s.invoiceId, s.date, s.customerName || 'Walk-in', s.items.length.toString(), s.paymentMethod, s.totalAmount.toString()]));
    } else if (activeReport === 'expiry') {
      rows.push(['Medicine Name', 'Batch Number', 'Category', 'Quantity', 'Expiry Date', 'Days Left', 'Risk Level']);
      expiryRisks.forEach(r => rows.push([r.medicineName, r.batchNumber, r.category, r.quantity.toString(), r.expiryDate, r.daysRemaining.toString(), r.riskTier]));
    } else if (activeReport === 'forecast') {
      rows.push(['Medicine ID', 'Name', 'Current Stock', '7-Day Projected Demand', 'Safety Stock', 'Suggested Reorder', 'Priority']);
      forecasts.forEach(f => rows.push([f.medicineId, f.medicineName, f.currentStock.toString(), f.predictedDemand7Days.toString(), f.safetyStock.toString(), f.recommendedQuantity.toString(), f.priority]));
    } else if (activeReport === 'suppliers') {
      rows.push(['Supplier ID', 'Name', 'Contact Person', 'Email', 'Phone', 'Lead Time Days', 'MOQ']);
      suppliers.forEach(s => rows.push([s.supplierId, s.name, s.contactPerson, s.email, s.phone, s.leadTimeDays.toString(), s.moq.toString()]));
    }

    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadMsg(true);
    setTimeout(() => setDownloadMsg(false), 2500);
  };

  return (
    <div className="space-y-6">
      
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Reports & Business Analytics</h1>
          <p className="text-xs text-slate-500">Export structured CSV data for audits, sales reviews, and stock valuations</p>
        </div>

        <button
          onClick={exportCSV}
          className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5"
        >
          <Download className="w-4 h-4" /> Export CSV Report
        </button>
      </div>

      {downloadMsg && (
        <div className="bg-teal-50 border border-teal-200 text-teal-900 p-3 rounded-2xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-teal-600" /> Report exported successfully to CSV!
        </div>
      )}

      {/* Report Type Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 text-xs font-semibold">
        {[
          { id: 'inventory', label: 'Inventory Valuation Report' },
          { id: 'sales', label: 'Sales & Revenue Summary' },
          { id: 'expiry', label: 'Expiry Risk Audit' },
          { id: 'forecast', label: 'Demand Forecast Report' },
          { id: 'suppliers', label: 'Supplier SLA Report' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveReport(t.id as any)}
            className={`px-4 py-2 rounded-xl transition ${
              activeReport === t.id ? 'bg-white text-teal-700 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Report Preview Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 capitalize">{activeReport} Data Preview ({
          activeReport === 'inventory' ? medicines.length :
          activeReport === 'sales' ? sales.length :
          activeReport === 'expiry' ? expiryRisks.length :
          activeReport === 'forecast' ? forecasts.length : suppliers.length
        } Records)</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                {activeReport === 'inventory' && (
                  <>
                    <th className="py-3 px-4">SKU ID</th>
                    <th className="py-3 px-4">Medicine Name</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Stock Qty</th>
                    <th className="py-3 px-4">Price</th>
                  </>
                )}
                {activeReport === 'sales' && (
                  <>
                    <th className="py-3 px-4">Invoice ID</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Payment Method</th>
                    <th className="py-3 px-4">Total (₹)</th>
                  </>
                )}
                {activeReport === 'expiry' && (
                  <>
                    <th className="py-3 px-4">Medicine</th>
                    <th className="py-3 px-4">Batch</th>
                    <th className="py-3 px-4">Expiry Date</th>
                    <th className="py-3 px-4">Days Left</th>
                    <th className="py-3 px-4">Risk Tier</th>
                  </>
                )}
                {activeReport === 'forecast' && (
                  <>
                    <th className="py-3 px-4">Medicine</th>
                    <th className="py-3 px-4">Current Stock</th>
                    <th className="py-3 px-4">7-Day Demand</th>
                    <th className="py-3 px-4">Reorder Qty</th>
                    <th className="py-3 px-4">Priority</th>
                  </>
                )}
                {activeReport === 'suppliers' && (
                  <>
                    <th className="py-3 px-4">Supplier ID</th>
                    <th className="py-3 px-4">Supplier Name</th>
                    <th className="py-3 px-4">Contact</th>
                    <th className="py-3 px-4">Lead Time SLA</th>
                    <th className="py-3 px-4">MOQ</th>
                  </>
                )}
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {activeReport === 'inventory' && medicines.map((m) => (
                <tr key={m.id} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-mono font-bold text-slate-800">{m.medicineId}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">{m.name}</td>
                  <td className="py-3 px-4 text-slate-600">{m.category}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{m.stockQuantity}</td>
                  <td className="py-3 px-4 font-bold text-teal-700">₹{m.finalPrice.toFixed(2)}</td>
                </tr>
              ))}

              {activeReport === 'sales' && sales.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-mono font-bold text-slate-800">{s.invoiceId}</td>
                  <td className="py-3 px-4 text-slate-600">{s.date}</td>
                  <td className="py-3 px-4 text-slate-800 font-semibold">{s.customerName}</td>
                  <td className="py-3 px-4 font-bold text-slate-700">{s.paymentMethod}</td>
                  <td className="py-3 px-4 font-black text-slate-900">₹{s.totalAmount.toFixed(2)}</td>
                </tr>
              ))}

              {activeReport === 'expiry' && expiryRisks.map((r, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-slate-900">{r.medicineName}</td>
                  <td className="py-3 px-4 font-mono text-slate-600">{r.batchNumber}</td>
                  <td className="py-3 px-4 font-semibold text-slate-700">{r.expiryDate}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{r.daysRemaining} days</td>
                  <td className="py-3 px-4 font-bold text-teal-700">{r.riskTier}</td>
                </tr>
              ))}

              {activeReport === 'forecast' && forecasts.map((f) => (
                <tr key={f.medicineId} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-slate-900">{f.medicineName}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{f.currentStock}</td>
                  <td className="py-3 px-4 font-semibold text-slate-700">{f.predictedDemand7Days} units</td>
                  <td className="py-3 px-4 font-extrabold text-teal-700">{f.recommendedQuantity}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{f.priority}</td>
                </tr>
              ))}

              {activeReport === 'suppliers' && suppliers.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-mono font-bold text-slate-800">{s.supplierId}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">{s.name}</td>
                  <td className="py-3 px-4 text-slate-600">{s.phone}</td>
                  <td className="py-3 px-4 font-bold text-slate-800">{s.leadTimeDays} Days</td>
                  <td className="py-3 px-4 font-bold text-teal-700">{s.moq} Units</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
