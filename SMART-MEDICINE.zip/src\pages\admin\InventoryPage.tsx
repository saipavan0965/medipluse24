import React, { useState } from 'react';
import { Medicine } from '../../types';
import { useData } from '../../context/DataContext';
import { Pill, Plus, Search, Edit3, Trash2, ShieldAlert, CheckCircle, Clock, X, AlertCircle } from 'lucide-react';

export const InventoryPage: React.FC = () => {
  const { medicines, addMedicine, updateMedicine, deleteMedicine, updateStockQuantity } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCat, setFilterCat] = useState('ALL');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);

  // Form State
  const [formState, setFormState] = useState<Partial<Medicine>>({
    name: '',
    brand: '',
    manufacturer: '',
    category: 'Fever & Pain Relief',
    description: '',
    price: 100,
    discountPercentage: 10,
    stockQuantity: 50,
    reorderLevel: 20,
    safetyStock: 10,
    batchNumber: 'BT-2026-01',
    expiryDate: '2027-12-31',
    supplier: 'MedPharma Distribution',
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80'
  });

  const filteredMedicines = medicines.filter(m => {
    const matchQuery = m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.medicineId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.batchNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchCat = filterCat === 'ALL' || m.category === filterCat;
    return matchQuery && matchCat;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMed) {
      updateMedicine(editingMed.id, formState);
      setEditingMed(null);
    } else {
      addMedicine(formState);
      setIsAddOpen(false);
    }
    setFormState({
      name: '',
      brand: '',
      manufacturer: '',
      category: 'Fever & Pain Relief',
      description: '',
      price: 100,
      discountPercentage: 10,
      stockQuantity: 50,
      reorderLevel: 20,
      safetyStock: 10,
      batchNumber: 'BT-2026-01',
      expiryDate: '2027-12-31',
      supplier: 'MedPharma Distribution',
      prescriptionRequired: false,
      image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80'
    });
  };

  const handleEditClick = (med: Medicine) => {
    setEditingMed(med);
    setFormState(med);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Medicine Stock & Inventory Control</h1>
          <p className="text-xs text-slate-500">Manage SKUs, batch numbers, reorder thresholds, and pricing</p>
        </div>

        <button
          onClick={() => { setEditingMed(null); setIsAddOpen(true); }}
          className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Add New Medicine
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder="Search medicine name, SKU, brand or batch..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-100 text-xs text-slate-800 placeholder-slate-400 pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Category:</span>
          <select
            value={filterCat}
            onChange={(e) => setFilterCat(e.target.value)}
            className="bg-slate-50 text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-semibold focus:outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="Fever & Pain Relief">Fever & Pain Relief</option>
            <option value="Cold & Cough">Cold & Cough</option>
            <option value="Respiratory Care">Respiratory Care</option>
            <option value="Diabetes Care">Diabetes Care</option>
            <option value="Heart Care">Heart Care</option>
            <option value="Vitamins & Supplements">Vitamins & Supplements</option>
            <option value="Digestive Care">Digestive Care</option>
            <option value="First Aid">First Aid</option>
          </select>
        </div>
      </div>

      {/* Main Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3.5 px-4">Medicine & Mfr</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Batch No</th>
                <th className="py-3.5 px-4">Price (MRP / Final)</th>
                <th className="py-3.5 px-4">Available Stock</th>
                <th className="py-3.5 px-4">Reorder Pt</th>
                <th className="py-3.5 px-4">Expiry Date</th>
                <th className="py-3.5 px-4">Supplier</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredMedicines.map((med) => {
                const isLow = med.stockQuantity > 0 && med.stockQuantity <= med.reorderLevel;
                const isOut = med.stockQuantity === 0;

                return (
                  <tr key={med.id} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-2">
                        <img src={med.image} alt={med.name} className="w-8 h-8 object-contain bg-slate-50 rounded p-0.5" />
                        <div>
                          <div className="line-clamp-1">{med.name}</div>
                          <div className="text-[10px] text-slate-400 font-medium">{med.brand} • {med.medicineId}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-slate-600 font-semibold">{med.category}</td>
                    <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">{med.batchNumber}</td>
                    
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">₹{med.finalPrice.toFixed(2)}</div>
                      {med.discountPercentage > 0 && (
                        <div className="text-[10px] text-slate-400 line-through">₹{med.price.toFixed(2)}</div>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`font-extrabold text-sm ${isOut ? 'text-red-600' : isLow ? 'text-amber-600' : 'text-slate-800'}`}>
                          {med.stockQuantity}
                        </span>
                        
                        {/* Quick Stock Controls */}
                        <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-md">
                          <button
                            onClick={() => updateStockQuantity(med.id, med.stockQuantity - 5)}
                            className="px-1.5 py-0.5 bg-white text-slate-700 hover:bg-slate-200 rounded font-bold text-[10px]"
                            title="Quick minus 5"
                          >
                            -5
                          </button>
                          <button
                            onClick={() => updateStockQuantity(med.id, med.stockQuantity + 10)}
                            className="px-1.5 py-0.5 bg-white text-slate-700 hover:bg-slate-200 rounded font-bold text-[10px]"
                            title="Quick add 10"
                          >
                            +10
                          </button>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-slate-500 font-medium">{med.reorderLevel} units</td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{med.expiryDate}</td>
                    <td className="py-3 px-4 text-slate-500 text-[11px]">{med.supplier}</td>

                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleEditClick(med)}
                          className="p-1.5 text-slate-600 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition"
                          title="Edit Medicine"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteMedicine(med.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                          title="Delete Medicine"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Medicine Modal Dialog */}
      {(isAddOpen || editingMed) && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingMed ? 'Edit Medicine SKU' : 'Add New Medicine Formulation'}
              </h3>
              <button
                onClick={() => { setIsAddOpen(false); setEditingMed(null); }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Medicine Name</label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Brand Name</label>
                  <input
                    type="text"
                    required
                    value={formState.brand}
                    onChange={(e) => setFormState({ ...formState, brand: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Category</label>
                  <select
                    value={formState.category}
                    onChange={(e) => setFormState({ ...formState, category: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="Fever & Pain Relief">Fever & Pain Relief</option>
                    <option value="Cold & Cough">Cold & Cough</option>
                    <option value="Respiratory Care">Respiratory Care</option>
                    <option value="Diabetes Care">Diabetes Care</option>
                    <option value="Heart Care">Heart Care</option>
                    <option value="Vitamins & Supplements">Vitamins & Supplements</option>
                    <option value="Digestive Care">Digestive Care</option>
                    <option value="First Aid">First Aid</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Batch Number</label>
                  <input
                    type="text"
                    required
                    value={formState.batchNumber}
                    onChange={(e) => setFormState({ ...formState, batchNumber: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Purchase Price (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formState.price}
                    onChange={(e) => setFormState({ ...formState, price: Number(e.target.value) })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Discount %</label>
                  <input
                    type="number"
                    value={formState.discountPercentage}
                    onChange={(e) => setFormState({ ...formState, discountPercentage: Number(e.target.value) })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    required
                    value={formState.stockQuantity}
                    onChange={(e) => setFormState({ ...formState, stockQuantity: Number(e.target.value) })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 font-bold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Reorder Point Level</label>
                  <input
                    type="number"
                    required
                    value={formState.reorderLevel}
                    onChange={(e) => setFormState({ ...formState, reorderLevel: Number(e.target.value) })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={formState.expiryDate}
                    onChange={(e) => setFormState({ ...formState, expiryDate: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500 font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Supplier</label>
                  <input
                    type="text"
                    value={formState.supplier}
                    onChange={(e) => setFormState({ ...formState, supplier: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formState.prescriptionRequired}
                    onChange={(e) => setFormState({ ...formState, prescriptionRequired: e.target.checked })}
                    className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                  />
                  <span>Prescription Required (Rx)</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => { setIsAddOpen(false); setEditingMed(null); }}
                  className="px-4 py-2 border border-slate-200 text-slate-600 text-xs font-bold rounded-xl hover:bg-slate-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md"
                >
                  {editingMed ? 'Save Medicine Edits' : 'Save to Inventory'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
