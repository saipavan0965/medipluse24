import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { PurchaseOrder, POStatus } from '../../types';
import { FileText, Plus, CheckCircle, Clock, Truck, PackageCheck, AlertCircle } from 'lucide-react';

export const PurchaseOrdersPage: React.FC = () => {
  const { purchaseOrders, createPurchaseOrder, updatePOStatus, medicines, suppliers } = useData();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedMed, setSelectedMed] = useState(medicines[0]?.medicineId || '');
  const [selectedSup, setSelectedSup] = useState(suppliers[0]?.supplierId || '');
  const [quantity, setQuantity] = useState(100);

  const poStatuses: POStatus[] = ['Draft', 'Pending Approval', 'Ordered', 'Shipped', 'Received', 'Cancelled'];

  const handleCreatePO = (e: React.FormEvent) => {
    e.preventDefault();
    const med = medicines.find(m => m.medicineId === selectedMed || m.id === selectedMed);
    const sup = suppliers.find(s => s.supplierId === selectedSup || s.id === selectedSup);

    createPurchaseOrder({
      medicineId: selectedMed,
      medicineName: med?.name || 'Selected Medicine',
      supplierId: selectedSup,
      supplierName: sup?.name || 'Selected Supplier',
      quantity,
      unitCost: med ? Math.round(med.price * 0.7) : 40,
      status: 'Pending Approval'
    });

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Purchase Orders (PO) Management</h1>
          <p className="text-xs text-slate-500">Track replenishment orders with distributors and automatically update stock upon receiving</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Generate Purchase Order
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3.5 px-4">PO Number & Date</th>
                <th className="py-3.5 px-4">Supplier Distributor</th>
                <th className="py-3.5 px-4">Medicine Item</th>
                <th className="py-3.5 px-4">Ordered Quantity</th>
                <th className="py-3.5 px-4">Total Cost</th>
                <th className="py-3.5 px-4">PO Status</th>
                <th className="py-3.5 px-4 text-center">Status Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {purchaseOrders.map((po) => (
                <tr key={po.id} className="hover:bg-slate-50 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{po.poNumber}</div>
                    <div className="text-[10px] text-slate-400 font-medium">{po.orderDate}</div>
                  </td>

                  <td className="py-3 px-4 font-semibold text-slate-800">{po.supplierName}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">{po.medicineName}</td>
                  <td className="py-3 px-4 font-extrabold text-teal-700">{po.quantity} units</td>
                  <td className="py-3 px-4 font-extrabold text-slate-900">₹{po.totalCost.toFixed(2)}</td>

                  <td className="py-3 px-4">
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                      po.status === 'Received'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : po.status === 'Ordered' || po.status === 'Shipped'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-900'
                    }`}>
                      {po.status}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <select
                      value={po.status}
                      onChange={(e) => updatePOStatus(po.id, e.target.value as POStatus)}
                      className="bg-slate-50 text-[11px] font-bold text-slate-800 border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:border-teal-500"
                    >
                      {poStatuses.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New PO Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <h3 className="text-base font-bold text-slate-900 pb-2 border-b border-slate-100">Draft New Purchase Order</h3>

            <form onSubmit={handleCreatePO} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Select Medicine SKU</label>
                <select
                  value={selectedMed}
                  onChange={(e) => setSelectedMed(e.target.value)}
                  className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                >
                  {medicines.map(m => (
                    <option key={m.id} value={m.medicineId || m.id}>{m.name} ({m.brand})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Select Supplier</label>
                <select
                  value={selectedSup}
                  onChange={(e) => setSelectedSup(e.target.value)}
                  className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none"
                >
                  {suppliers.map(s => (
                    <option key={s.id} value={s.supplierId || s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Order Quantity (Units)</label>
                <input
                  type="number"
                  min="10"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none font-bold"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-sm"
                >
                  Create Purchase Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
