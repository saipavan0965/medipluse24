import React, { useState, useMemo } from 'react';
import { Medicine } from '../types';
import { MedicineCard } from '../components/customer/MedicineCard';
import { Search, Filter, SlidersHorizontal, ShieldAlert, CheckCircle, Info, Sparkles } from 'lucide-react';

interface MedicinesPageProps {
  medicines: Medicine[];
  initialQuery?: string;
  initialCategory?: string;
  onViewDetails: (med: Medicine) => void;
  onBuyNow: (med: Medicine) => void;
}

export const MedicinesPage: React.FC<MedicinesPageProps> = ({
  medicines,
  initialQuery = '',
  initialCategory = 'ALL',
  onViewDetails,
  onBuyNow
}) => {
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [selectedBrand, setSelectedBrand] = useState('ALL');
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'rating'>('popular');

  const categories = ['ALL', 'Fever & Pain Relief', 'Cold & Cough', 'Respiratory Care', 'Diabetes Care', 'Heart Care', 'Vitamins & Supplements', 'Digestive Care', 'First Aid'];

  const brands = useMemo(() => {
    const set = new Set(medicines.map(m => m.brand));
    return ['ALL', ...Array.from(set)];
  }, [medicines]);

  const filteredMedicines = useMemo(() => {
    return medicines.filter(m => {
      const matchSearch =
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchCategory = selectedCategory === 'ALL' || m.category === selectedCategory;
      const matchBrand = selectedBrand === 'ALL' || m.brand === selectedBrand;
      const matchStock = !onlyInStock || m.stockQuantity > 0;

      return matchSearch && matchCategory && matchBrand && matchStock;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.finalPrice - b.finalPrice;
      if (sortBy === 'price-high') return b.finalPrice - a.finalPrice;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });
  }, [medicines, searchTerm, selectedCategory, selectedBrand, onlyInStock, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Demo Banner */}
      <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-teal-900">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
          <span className="font-semibold">Demo Pharmacy Catalog: Featuring 15+ genuine medicine formulations with live inventory tracking.</span>
        </div>
        <span className="bg-teal-600 text-white font-bold px-2.5 py-0.5 rounded-md text-[10px]">DEMO DATA</span>
      </div>

      {/* Title & Filter Bar Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Medicine Catalogue & Online Pharmacy</h1>
          <p className="text-xs text-slate-500">Showing {filteredMedicines.length} verified products</p>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">Sort By:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white text-xs border border-slate-200 rounded-xl px-3 py-2 font-semibold text-slate-800 focus:outline-none focus:border-teal-500"
          >
            <option value="popular">Popularity & Relevance</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">User Rating</option>
          </select>
        </div>
      </div>

      {/* Main Grid with Sidebar Filter Column */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Filters Column (3 cols) */}
        <div className="lg:col-span-3 space-y-6">
          
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal className="w-4 h-4 text-teal-600" /> Filter Catalogue
              </h3>
              {(selectedCategory !== 'ALL' || selectedBrand !== 'ALL' || onlyInStock || searchTerm) && (
                <button
                  onClick={() => {
                    setSelectedCategory('ALL');
                    setSelectedBrand('ALL');
                    setOnlyInStock(false);
                    setSearchTerm('');
                  }}
                  className="text-[11px] font-bold text-red-600 hover:underline"
                >
                  Reset
                </button>
              )}
            </div>

            {/* Search Input */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1.5">Search Keyword</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search name, brand, symptom..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-50 text-xs text-slate-800 placeholder-slate-400 pl-8 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1.5">Therapeutic Category</label>
              <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                      selectedCategory === cat
                        ? 'bg-teal-50 text-teal-800 font-bold border border-teal-200'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Brand Filter */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1.5">Brand / Mfr</label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full bg-slate-50 text-xs border border-slate-200 rounded-xl px-2.5 py-2 text-slate-800 font-medium focus:outline-none"
              >
                {brands.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Availability Checkbox */}
            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyInStock}
                  onChange={(e) => setOnlyInStock(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                />
                <span>In-Stock Items Only</span>
              </label>
            </div>

          </div>

        </div>

        {/* Right Medicines Grid (9 cols) */}
        <div className="lg:col-span-9 space-y-6">
          {filteredMedicines.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <Info className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No matching medicines found</h3>
              <p className="text-xs text-slate-500">Try adjusting your search keywords or clearing filter choices.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMedicines.map((med) => (
                <MedicineCard
                  key={med.id}
                  medicine={med}
                  onViewDetails={onViewDetails}
                  onBuyNow={onBuyNow}
                />
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
