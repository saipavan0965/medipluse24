import React from 'react';
import { useData } from '../../context/DataContext';
import { AIAssistantModal } from '../../components/admin/AIAssistantModal';

export const AIAssistantPage: React.FC = () => {
  const { medicines } = useData();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">MediPulse AI Assistant</h1>
        <p className="text-xs text-slate-500">Conversational natural language interface for real-time inventory queries and supply insights</p>
      </div>

      <AIAssistantModal medicines={medicines} />
    </div>
  );
};
