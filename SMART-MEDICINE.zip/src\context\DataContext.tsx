import React, { createContext, useContext, useState, useEffect } from 'react';
import { Medicine, HealthcareProduct, Supplier, PurchaseOrder, Order, SalesTransaction, Offer, HealthTip, DemandForecast, ExpiryRiskItem } from '../types';
import { ApiService } from '../services/api';
import { generateDemandForecasts, analyzeExpiryRisks } from '../services/aiEngine';

interface DataContextType {
  medicines: Medicine[];
  products: HealthcareProduct[];
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  orders: Order[];
  sales: SalesTransaction[];
  offers: Offer[];
  healthTips: HealthTip[];
  activeSeason: string;
  setActiveSeason: (season: string) => void;

  // Medicine Inventory CRUD & Stock Updates
  addMedicine: (med: Partial<Medicine>) => void;
  updateMedicine: (id: string, updated: Partial<Medicine>) => void;
  deleteMedicine: (id: string) => void;
  updateStockQuantity: (id: string, newQty: number) => void;

  // PO Management & Automated AI Reorder
  createPurchaseOrder: (po: Partial<PurchaseOrder>) => void;
  updatePOStatus: (id: string, status: PurchaseOrder['status']) => void;
  approveReorderForecast: (forecast: DemandForecast) => void;

  // Order Management
  createCustomerOrder: (order: Order) => Promise<Order>;
  updateOrderStatus: (id: string, status: Order['orderStatus']) => void;

  // POS Billing Transaction
  recordPOSTransaction: (items: { medicineId: string; medicineName: string; quantity: number; price: number; subtotal: number }[], paymentMethod: string, customerName?: string) => void;

  // Analytical Computed Engine
  forecasts: DemandForecast[];
  expiryRisks: ExpiryRiskItem[];
  refreshData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [products, setProducts] = useState<HealthcareProduct[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [sales, setSales] = useState<SalesTransaction[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [healthTips, setHealthTips] = useState<HealthTip[]>([]);
  const [activeSeason, setActiveSeason] = useState<string>('Monsoon');

  const loadAll = async () => {
    const meds = await ApiService.getMedicines();
    const prods = await ApiService.getHealthcareProducts();
    const sups = await ApiService.getSuppliers();
    const pos = await ApiService.getPurchaseOrders();
    const ords = await ApiService.getOrders();
    const sls = await ApiService.getSales();
    const offs = await ApiService.getOffers();
    const tips = await ApiService.getHealthTips();

    setMedicines(meds);
    setProducts(prods);
    setSuppliers(sups);
    setPurchaseOrders(pos);
    setOrders(ords);
    setSales(sls);
    setOffers(offs);
    setHealthTips(tips);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const addMedicine = (medData: Partial<Medicine>) => {
    const newMed: Medicine = {
      id: `med-${Date.now()}`,
      medicineId: medData.medicineId || `MED-${Math.floor(1000 + Math.random() * 9000)}`,
      name: medData.name || 'New Medicine',
      brand: medData.brand || 'Generic',
      manufacturer: medData.manufacturer || 'Pharma Corp',
      category: medData.category || 'Fever & Pain Relief',
      description: medData.description || 'Medicine formulation',
      price: medData.price || 100,
      discountPercentage: medData.discountPercentage || 0,
      finalPrice: (medData.price || 100) * (1 - (medData.discountPercentage || 0) / 100),
      stockQuantity: medData.stockQuantity || 50,
      reorderLevel: medData.reorderLevel || 20,
      safetyStock: medData.safetyStock || 10,
      batchNumber: medData.batchNumber || `BT-${new Date().getFullYear()}-01`,
      expiryDate: medData.expiryDate || '2027-12-31',
      supplier: medData.supplier || 'MedPharma Distribution',
      image: medData.image || 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80',
      prescriptionRequired: medData.prescriptionRequired || false,
      rating: 4.5
    };
    const updated = [newMed, ...medicines];
    setMedicines(updated);
    ApiService.saveMedicines(updated);
  };

  const updateMedicine = (id: string, updated: Partial<Medicine>) => {
    const next = medicines.map(m => {
      if (m.id === id || m.medicineId === id) {
        const price = updated.price !== undefined ? updated.price : m.price;
        const discountPercentage = updated.discountPercentage !== undefined ? updated.discountPercentage : m.discountPercentage;
        const finalPrice = Math.round(price * (1 - discountPercentage / 100) * 100) / 100;
        return { ...m, ...updated, finalPrice };
      }
      return m;
    });
    setMedicines(next);
    ApiService.saveMedicines(next);
  };

  const deleteMedicine = (id: string) => {
    const next = medicines.filter(m => m.id !== id && m.medicineId !== id);
    setMedicines(next);
    ApiService.saveMedicines(next);
  };

  const updateStockQuantity = (id: string, newQty: number) => {
    updateMedicine(id, { stockQuantity: Math.max(0, newQty) });
  };

  const createPurchaseOrder = (poData: Partial<PurchaseOrder>) => {
    const newPO: PurchaseOrder = {
      id: `po-${Date.now()}`,
      poNumber: poData.poNumber || `PO-2026-${Math.floor(100 + Math.random() * 900)}`,
      supplierId: poData.supplierId || 'SUP-101',
      supplierName: poData.supplierName || 'MedPharma Distribution Pvt Ltd',
      medicineId: poData.medicineId || 'MED-1001',
      medicineName: poData.medicineName || 'Paracetamol 650mg',
      quantity: poData.quantity || 100,
      unitCost: poData.unitCost || 25,
      totalCost: (poData.quantity || 100) * (poData.unitCost || 25),
      status: poData.status || 'Pending Approval',
      orderDate: new Date().toISOString().split('T')[0],
      expectedDeliveryDate: new Date(Date.now() + 3 * 24 * 3600 * 1000).toISOString().split('T')[0]
    };
    const updated = [newPO, ...purchaseOrders];
    setPurchaseOrders(updated);
    ApiService.savePurchaseOrders(updated);
  };

  const updatePOStatus = (id: string, status: PurchaseOrder['status']) => {
    const next = purchaseOrders.map(p => {
      if (p.id === id) {
        // If PO status changes to 'Received', automatically replenish stock in Inventory!
        if (status === 'Received' && p.status !== 'Received') {
          const targetMed = medicines.find(m => m.medicineId === p.medicineId || m.id === p.medicineId);
          if (targetMed) {
            updateStockQuantity(targetMed.id, targetMed.stockQuantity + p.quantity);
          }
        }
        return { ...p, status };
      }
      return p;
    });
    setPurchaseOrders(next);
    ApiService.savePurchaseOrders(next);
  };

  const approveReorderForecast = (forecast: DemandForecast) => {
    const targetMed = medicines.find(m => m.medicineId === forecast.medicineId || m.id === forecast.medicineId);
    const supplierName = targetMed?.supplier || 'MedPharma Distribution Pvt Ltd';
    createPurchaseOrder({
      medicineId: forecast.medicineId,
      medicineName: forecast.medicineName,
      quantity: forecast.recommendedQuantity,
      unitCost: targetMed ? Math.round(targetMed.price * 0.7) : 50,
      supplierName,
      status: 'Pending Approval'
    });
  };

  const createCustomerOrder = async (order: Order): Promise<Order> => {
    const created = await ApiService.createOrder(order);
    setOrders(prev => [created, ...prev]);

    // Automatically deduct inventory stock for ordered items
    order.items.forEach(item => {
      const med = medicines.find(m => m.id === item.productId || m.medicineId === item.productId);
      if (med) {
        updateStockQuantity(med.id, Math.max(0, med.stockQuantity - item.quantity));
      }
    });

    return created;
  };

  const updateOrderStatus = (id: string, status: Order['orderStatus']) => {
    const next = orders.map(o => (o.id === id || o.orderId === id ? { ...o, orderStatus: status } : o));
    setOrders(next);
    localStorage.setItem('medipulse_orders', JSON.stringify(next));
  };

  const recordPOSTransaction = (items: { medicineId: string; medicineName: string; quantity: number; price: number; subtotal: number }[], paymentMethod: string, customerName = 'Walk-in Customer') => {
    const totalAmount = items.reduce((sum, i) => sum + i.subtotal, 0);
    const newSale: SalesTransaction = {
      id: `sale-${Date.now()}`,
      invoiceId: `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      items,
      totalAmount,
      paymentMethod,
      customerName
    };
    ApiService.recordSale(newSale).then(saved => {
      setSales(prev => [saved, ...prev]);
    });

    // Deduct inventory stock immediately
    items.forEach(item => {
      const med = medicines.find(m => m.id === item.medicineId || m.medicineId === item.medicineId);
      if (med) {
        updateStockQuantity(med.id, Math.max(0, med.stockQuantity - item.quantity));
      }
    });
  };

  // AI Calculations
  const forecasts = generateDemandForecasts(medicines, activeSeason);
  const expiryRisks = analyzeExpiryRisks(medicines);

  return (
    <DataContext.Provider
      value={{
        medicines,
        products,
        suppliers,
        purchaseOrders,
        orders,
        sales,
        offers,
        healthTips,
        activeSeason,
        setActiveSeason,
        addMedicine,
        updateMedicine,
        deleteMedicine,
        updateStockQuantity,
        createPurchaseOrder,
        updatePOStatus,
        approveReorderForecast,
        createCustomerOrder,
        updateOrderStatus,
        recordPOSTransaction,
        forecasts,
        expiryRisks,
        refreshData: loadAll
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
