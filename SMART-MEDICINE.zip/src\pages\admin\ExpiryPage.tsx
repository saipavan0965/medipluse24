import React from 'react';
import { useData } from '../../context/DataContext';
import { ExpiryMatrix } from '../../components/admin/ExpiryMatrix';
import { AlertTriangle, Clock, Sparkles } from 'lucide-react';

export const ExpiryPage: React.FC = () => {
  const { expiryRisks } = useData();

  return (
    <div className="space-y-6">
      
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold mb-1.5">
          <Clock className="w-4 h-4 text-amber-600" /> First-Expiry-First-Out (FEFO) Audit Engine
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Batch Expiry Management Console</h1>
        <p className="text-xs text-slate-500">Monitor batch expiration dates, identify near-expiry risks, and execute promotional discounts</p>
      </div>

      <ExpiryMatrix expiryRisks={expiryRisks} />

    </div>
  );
};
