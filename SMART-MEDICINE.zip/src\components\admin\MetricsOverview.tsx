import React from 'react';
import { Medicine, Order, SalesTransaction, ExpiryRiskItem } from '../../types';
import { Pill, AlertTriangle, TrendingUp, Package, Clock, ShoppingCart, CheckCircle, XCircle } from 'lucide-react';

interface MetricsOverviewProps {
  medicines: Medicine[];
  orders: Order[];
  sales: SalesTransaction[];
  expiryRisks: ExpiryRiskItem[];
}

export const MetricsOverview: React.FC<MetricsOverviewProps> = ({ medicines, orders, sales, expiryRisks }) => {
  const totalMedicines = medicines.length;
  const totalStockUnits = medicines.reduce((sum, m) => sum + m.stockQuantity, 0);
  const lowStockCount = medicines.filter(m => m.stockQuantity > 0 && m.stockQuantity <= m.reorderLevel).length;
  const outOfStockCount = medicines.filter(m => m.stockQuantity === 0).length;
  
  const nearExpiryCount = expiryRisks.filter(r => r.riskTier === 'NEAR_EXPIRY' || r.riskTier === 'URGENT').length;
  const expiredCount = expiryRisks.filter(r => r.riskTier === 'EXPIRED').length;

  const todayStr = new Date().toISOString().split('T')[0];
  const todaySalesAmount = sales.reduce((sum, s) => sum + s.totalAmount, 0) + orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const pendingOrdersCount = orders.filter(o => o.orderStatus === 'Confirmed' || o.orderStatus === 'Packed').length;

  const metrics = [
    { title: 'Total Medicines', value: totalMedicines, label: 'Active SKUs', icon: Pill, color: 'text-teal-600 bg-teal-50 border-teal-200' },
    { title: 'Total Available Stock', value: `${totalStockUnits.toLocaleString()} units`, label: 'In Inventory', icon: Package, color: 'text-blue-600 bg-blue-50 border-blue-200' },
    { title: 'Low Stock Alert', value: lowStockCount, label: 'Below Reorder Level', icon: AlertTriangle, color: 'text-amber-600 bg-amber-50 border-amber-200' },
    { title: 'Out of Stock', value: outOfStockCount, label: 'Unavailable SKUs', icon: XCircle, color: 'text-rose-600 bg-rose-50 border-rose-200' },
    { title: 'Near Expiry (<60d)', value: nearExpiryCount, label: 'Requires Action', icon: Clock, color: 'text-orange-600 bg-orange-50 border-orange-200' },
    { title: 'Expired Stock', value: expiredCount, label: 'Quarantined SKUs', icon: AlertTriangle, color: 'text-red-600 bg-red-50 border-red-200' },
    { title: 'Today\'s Revenue', value: `₹${todaySalesAmount.toFixed(0)}`, label: 'Sales & POS Combined', icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
    { title: 'Pending Orders', value: pendingOrdersCount, label: 'Awaiting Fulfillment', icon: ShoppingCart, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((m, idx) => {
        const Icon = m.icon;
        return (
          <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{m.title}</span>
              <div className={`p-2.5 rounded-xl border ${m.color}`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
            <div className="text-2xl font-black text-slate-900 font-display tracking-tight">{m.value}</div>
            <p className="text-[11px] text-slate-400 font-semibold mt-1">{m.label}</p>
          </div>
        );
      })}
    </div>
  );
};
