import React, { useState } from 'react';
import { Medicine } from '../../types';
import { useCart } from '../../context/CartContext';
import { X, ShieldAlert, ShoppingBag, Zap, CheckCircle2, Clock, Truck, Plus, Minus, Star, Award } from 'lucide-react';

interface MedicineDetailsModalProps {
  medicine: Medicine | null;
  onClose: () => void;
  onProceedToCheckout: () => void;
}

export const MedicineDetailsModal: React.FC<MedicineDetailsModalProps> = ({ medicine, onClose, onProceedToCheckout }) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (!medicine) return null;

  const handleAddToCart = () => {
    addToCart(medicine, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    addToCart(medicine, quantity);
    onClose();
    onProceedToCheckout();
  };

  const isOutOfStock = medicine.stockQuantity === 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 px-6 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="bg-teal-100 text-teal-800 text-xs font-bold px-2.5 py-1 rounded-full border border-teal-200">
              {medicine.category}
            </span>
            <span className="text-xs text-slate-500 font-medium">Batch: {medicine.batchNumber}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 max-h-[75vh] overflow-y-auto">
          
          {/* Left Column: Image & Badges */}
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 flex items-center justify-center min-h-[220px]">
              <img
                src={medicine.image}
                alt={medicine.name}
                className="max-h-48 max-w-full object-contain"
              />
            </div>

            <div className="bg-teal-50/60 rounded-xl p-3 border border-teal-100 text-xs space-y-1.5">
              <div className="flex items-center gap-1.5 text-teal-800 font-bold">
                <Truck className="w-4 h-4 text-teal-600" /> Express Delivery Available
              </div>
              <p className="text-slate-600">Expected delivery within 24-48 hours with live order tracking.</p>
            </div>

            {medicine.prescriptionRequired && (
              <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                  <ShieldAlert className="w-4 h-4 text-amber-600" /> Prescription May Be Required
                </div>
                <p className="text-amber-800 leading-normal">
                  Upload or present valid doctor prescription according to applicable pharmacy regulations upon delivery.
                </p>
              </div>
            )}
          </div>

          {/* Right Column: Specs & Details */}
          <div className="space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">{medicine.brand}</span>
                <span className="flex items-center gap-1 text-xs font-bold text-slate-800">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {medicine.rating} ({medicine.reviewsCount || 100}+ reviews)
                </span>
              </div>

              <h2 className="text-xl font-bold text-slate-900 mt-1">{medicine.name}</h2>
              <p className="text-xs text-slate-500">Mfr: {medicine.manufacturer}</p>

              {/* Price Row */}
              <div className="mt-4 flex items-baseline gap-3">
                <span className="text-2xl font-black text-slate-900 font-display">₹{medicine.finalPrice.toFixed(2)}</span>
                {medicine.discountPercentage > 0 && (
                  <>
                    <span className="text-sm text-slate-400 line-through">₹{medicine.price.toFixed(2)}</span>
                    <span className="bg-red-100 text-red-700 text-xs font-bold px-2 py-0.5 rounded">
                      {medicine.discountPercentage}% OFF
                    </span>
                  </>
                )}
              </div>

              {/* Stock Indicator */}
              <div className="mt-3 flex items-center gap-2 text-xs">
                {isOutOfStock ? (
                  <span className="text-red-600 font-bold flex items-center gap-1">
                    <Clock className="w-4 h-4" /> Currently Out of Stock
                  </span>
                ) : (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> In Stock ({medicine.stockQuantity} units available)
                  </span>
                )}
                <span className="text-slate-400">|</span>
                <span className="text-slate-500">Exp: {medicine.expiryDate}</span>
              </div>

              {/* Description */}
              <div className="mt-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Description</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{medicine.description}</p>
              </div>

              {medicine.usage && (
                <div className="mt-3 space-y-1">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Usage Directions</h4>
                  <p className="text-xs text-slate-600">{medicine.usage}</p>
                </div>
              )}
            </div>

            {/* Quantity Selector & Action Buttons */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">Quantity:</span>
                <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1.5 rounded-lg bg-white shadow-sm text-slate-700 hover:bg-slate-50"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-8 text-center text-xs font-bold text-slate-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1.5 rounded-lg bg-white shadow-sm text-slate-700 hover:bg-slate-50"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  disabled={isOutOfStock}
                  onClick={handleAddToCart}
                  className="py-3 px-4 rounded-xl text-xs font-bold bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" /> Add to Cart
                </button>
                <button
                  disabled={isOutOfStock}
                  onClick={handleBuyNow}
                  className="py-3 px-4 rounded-xl text-xs font-bold bg-teal-600 hover:bg-teal-700 text-white shadow-md shadow-teal-500/20 transition flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4" /> Buy Now
                </button>
              </div>

              <p className="text-[10px] text-slate-400 text-center italic mt-2">
                Disclaimer: This platform provides product & inventory availability details and is not a substitute for professional medical advice.
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
