import React from 'react';
import { useData } from '../../context/DataContext';
import { ReorderTable } from '../../components/admin/ReorderTable';
import { DemandChart } from '../../components/admin/DemandChart';
import { TrendingUp, RefreshCw, Sparkles } from 'lucide-react';

export const ForecastPage: React.FC = () => {
  const { forecasts, expiryRisks, activeSeason, setActiveSeason } = useData();

  return (
    <div className="space-y-8">
      
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold mb-1.5">
            <Sparkles className="w-4 h-4 text-teal-600" /> AI Mathematical Forecasting & Buffer Math
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">AI Demand Forecasting & Re-Order Center</h1>
          <p className="text-xs text-slate-500">Projected 7/30-day medicine consumption based on sales velocity and lead times</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Season Simulation:</span>
          <select
            value={activeSeason}
            onChange={(e) => setActiveSeason(e.target.value)}
            className="bg-white text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none"
          >
            <option value="Monsoon">Monsoon (Flu & Respiratory Spike)</option>
            <option value="Summer">Summer (Dehydration & ORS Spike)</option>
            <option value="Winter">Winter (Joint Care & Cough Spike)</option>
            <option value="Spring">Spring (Allergy Spike)</option>
          </select>
        </div>
      </div>

      <DemandChart forecasts={forecasts} expiryRisks={expiryRisks} />

      <ReorderTable forecasts={forecasts} />

    </div>
  );
};
