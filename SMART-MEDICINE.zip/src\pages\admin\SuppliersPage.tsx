import React from 'react';
import { useData } from '../../context/DataContext';
import { Users, Phone, Mail, MapPin, Clock, Star } from 'lucide-react';

export const SuppliersPage: React.FC = () => {
  const { suppliers } = useData();

  return (
    <div className="space-y-6">
      
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Supplier Directory & Performance</h1>
        <p className="text-xs text-slate-500">Pharma distributors, lead time SLA, minimum order quantities (MOQ), and ratings</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {suppliers.map((sup) => (
          <div key={sup.id} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-100">{sup.supplierId}</span>
                <span className="flex items-center gap-1 text-xs font-bold text-slate-800">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {sup.rating}
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{sup.name}</h3>
              <p className="text-xs text-slate-500 font-medium">Contact: {sup.contactPerson}</p>

              <div className="space-y-2 text-xs text-slate-600 pt-2 border-t border-slate-100">
                <p className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-teal-600" /> {sup.phone}</p>
                <p className="flex items-center gap-2"><Mail className="w-3.5 h-3.5 text-teal-600" /> {sup.email}</p>
                <p className="flex items-start gap-2"><MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" /> <span>{sup.address}</span></p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-2xl">
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold">Lead Time SLA</span>
                <span className="font-extrabold text-slate-900">{sup.leadTimeDays} Days</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold">Min Order Qty</span>
                <span className="font-extrabold text-slate-900">{sup.moq} Units</span>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
