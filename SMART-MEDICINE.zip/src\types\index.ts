export type Role = 'CUSTOMER' | 'PHARMACY_STAFF' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: Role;
  addresses?: Address[];
  createdAt?: string;
}

export interface Address {
  id?: string;
  fullName: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  pincode: string;
  isDefault?: boolean;
}

export interface Batch {
  batchNumber: string;
  expiryDate: string; // YYYY-MM-DD
  quantity: number;
  purchasePrice: number;
  mrp: number;
}

export interface Medicine {
  id: string;
  medicineId: string;
  name: string;
  brand: string;
  manufacturer: string;
  category: string;
  description: string;
  usage?: string;
  warnings?: string;
  price: number;
  discountPercentage: number;
  finalPrice: number;
  stockQuantity: number;
  reorderLevel: number;
  safetyStock: number;
  batchNumber: string;
  expiryDate: string; // YYYY-MM-DD
  supplier: string;
  supplierId?: string;
  image: string;
  prescriptionRequired: boolean;
  rating: number;
  reviewsCount?: number;
  isHealthcareDevice?: boolean;
  batches?: Batch[];
}

export interface HealthcareProduct {
  id: string;
  name: string;
  category: string;
  brand: string;
  description: string;
  price: number;
  discountPercentage: number;
  finalPrice: number;
  stockQuantity: number;
  rating: number;
  image: string;
  warranty?: string;
}

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  brand: string;
  price: number;
  discountPercentage: number;
  finalPrice: number;
  image: string;
  quantity: number;
  prescriptionRequired?: boolean;
  isDevice?: boolean;
}

export type PaymentMethod = 'COD' | 'UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'NET_BANKING';
export type DeliveryType = 'STANDARD' | 'EXPRESS';
export type OrderStatus = 'Order Placed' | 'Confirmed' | 'Packed' | 'Shipped' | 'Out for Delivery' | 'Delivered' | 'Cancelled';

export interface Order {
  id: string;
  orderId: string;
  userId?: string;
  userName: string;
  userPhone: string;
  address: Address;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  codFee: number;
  discountAmount: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'PAID' | 'PENDING' | 'FAILED';
  deliveryType: DeliveryType;
  orderStatus: OrderStatus;
  estimatedDeliveryDate: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  supplierId: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  categories: string[];
  leadTimeDays: number;
  moq: number; // Minimum Order Quantity
  rating: number;
}

export type POStatus = 'Draft' | 'Pending Approval' | 'Ordered' | 'Shipped' | 'Received' | 'Cancelled';

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  medicineId: string;
  medicineName: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  status: POStatus;
  orderDate: string;
  expectedDeliveryDate: string;
}

export interface DemandForecast {
  medicineId: string;
  medicineName: string;
  category: string;
  currentStock: number;
  predictedDemand7Days: number;
  predictedDemand30Days: number;
  safetyStock: number;
  reorderPoint: number;
  recommendedQuantity: number;
  priority: 'URGENT' | 'HIGH' | 'MEDIUM' | 'LOW';
  confidenceScore: number; // percentage
  reason: string;
  seasonalFactor: number;
}

export interface ExpiryRiskItem {
  medicineId: string;
  medicineName: string;
  batchNumber: string;
  category: string;
  quantity: number;
  expiryDate: string;
  daysRemaining: number;
  riskTier: 'EXPIRED' | 'URGENT' | 'NEAR_EXPIRY' | 'NORMAL'; // EXPIRED: <=0, URGENT: <=30, NEAR_EXPIRY: <=60, NORMAL: >60
  recommendedAction: string;
}

export interface Offer {
  id: string;
  title: string;
  code: string;
  discountPercent: number;
  maxDiscount?: number;
  description: string;
  validUntil: string;
  category?: string;
  image?: string;
  isActive: boolean;
}

export interface HealthTip {
  id: string;
  title: string;
  category: string;
  shortDescription: string;
  content: string;
  image: string;
  readTime: string;
  author: string;
  date: string;
}

export interface Subscriber {
  id: string;
  email: string;
  subscribedAt: string;
}

export interface SalesTransaction {
  id: string;
  invoiceId: string;
  date: string;
  items: {
    medicineId: string;
    medicineName: string;
    quantity: number;
    price: number;
    subtotal: number;
  }[];
  totalAmount: number;
  paymentMethod: string;
  customerName?: string;
  customerPhone?: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  dataHighlights?: {
    type: 'low_stock' | 'expiry' | 'reorder' | 'sales' | 'general';
    items?: any[];
  };
}
