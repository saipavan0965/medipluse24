import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { OrderStatus } from '../../types';
import { FileText, Truck, Search, CheckCircle2, ChevronRight, MapPin } from 'lucide-react';

export const OrdersAdminPage: React.FC = () => {
  const { orders, updateOrderStatus } = useData();

  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const filteredOrders = orders.filter(o => {
    if (filterStatus === 'ALL') return true;
    return o.orderStatus === filterStatus;
  });

  const statuses: OrderStatus[] = ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

  return (
    <div className="space-y-6">
      
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Customer Orders & Fulfillment</h1>
          <p className="text-xs text-slate-500">Track online pharmacy orders, update shipping stages, and inspect invoices</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Filter Status:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-white text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none"
          >
            <option value="ALL">All Order Statuses</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3.5 px-4">Order ID & Date</th>
                <th className="py-3.5 px-4">Customer Name</th>
                <th className="py-3.5 px-4">Delivery Address</th>
                <th className="py-3.5 px-4">Items Summary</th>
                <th className="py-3.5 px-4">Total Paid</th>
                <th className="py-3.5 px-4">Payment & Type</th>
                <th className="py-3.5 px-4">Fulfillment Status</th>
                <th className="py-3.5 px-4 text-center">Update Pipeline</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredOrders.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-50 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{ord.orderId}</div>
                    <div className="text-[10px] text-slate-400 font-medium">{ord.createdAt}</div>
                  </td>

                  <td className="py-3 px-4 font-semibold text-slate-800">
                    <div>{ord.userName}</div>
                    <div className="text-[10px] text-slate-400">{ord.userPhone}</div>
                  </td>

                  <td className="py-3 px-4 text-slate-600 max-w-xs text-[11px]">
                    {ord.address.city}, {ord.address.state} - {ord.address.pincode}
                  </td>

                  <td className="py-3 px-4 font-medium text-slate-700">
                    {ord.items.length} SKUs ({ord.items.map(i => i.name).slice(0, 2).join(', ')})
                  </td>

                  <td className="py-3 px-4 font-extrabold text-slate-900">
                    ₹{ord.totalAmount.toFixed(2)}
                  </td>

                  <td className="py-3 px-4">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 block w-max">
                      {ord.paymentMethod}
                    </span>
                    <span className="text-[10px] text-teal-700 font-bold mt-0.5 block">{ord.deliveryType}</span>
                  </td>

                  <td className="py-3 px-4">
                    <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-slate-900 text-white">
                      {ord.orderStatus}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <select
                      value={ord.orderStatus}
                      onChange={(e) => updateOrderStatus(ord.id, e.target.value as OrderStatus)}
                      className="bg-slate-50 text-[11px] font-bold text-slate-800 border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:border-teal-500"
                    >
                      {statuses.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
