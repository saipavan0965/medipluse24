import React, { useState } from 'react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Order, PaymentMethod, DeliveryType, Address } from '../../types';
import { X, CheckCircle, Truck, CreditCard, MapPin, ShieldCheck, Zap, ArrowRight, ArrowLeft } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderComplete: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, onOrderComplete }) => {
  const { cart, subtotal, deliveryCharge, codFee, discountAmount, totalAmount, deliveryType, setDeliveryType, paymentMethod, setPaymentMethod, clearCart } = useCart();
  const { user } = useAuth();
  const { createCustomerOrder } = useData();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Address Form State
  const [address, setAddress] = useState<Address>({
    fullName: user?.name || 'Dr. Rajesh Sharma',
    phone: user?.phone || '+91 98765 43210',
    street: 'Flat 402, Sunshine Apartments, MG Road',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560001'
  });

  // Card / UPI Mock Inputs
  const [upiId, setUpiId] = useState('user@upi');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8892');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    const orderId = `MP-ORD-${Math.floor(100000 + Math.random() * 900000)}`;
    const estDate = deliveryType === 'EXPRESS' ? '2026-08-20 (Tomorrow)' : '2026-08-23 (Standard)';

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderId,
      userId: user?.id,
      userName: address.fullName,
      userPhone: address.phone,
      address,
      items: [...cart],
      subtotal,
      deliveryCharge,
      codFee,
      discountAmount,
      totalAmount,
      paymentMethod,
      paymentStatus: paymentMethod === 'COD' ? 'PENDING' : 'PAID',
      deliveryType,
      orderStatus: 'Confirmed',
      estimatedDeliveryDate: estDate,
      createdAt: new Date().toISOString().split('T')[0]
    };

    // Simulated payment processing delay
    setTimeout(async () => {
      const created = await createCustomerOrder(newOrder);
      setCompletedOrder(created);
      clearCart();
      setIsProcessing(false);
      setStep(4);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">MediPulse Express Checkout</h3>
            <p className="text-xs text-slate-500">Secure Pharmacy Order Processing</p>
          </div>
          {step !== 4 && (
            <button onClick={onClose} className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Step Indicator */}
        {step !== 4 && (
          <div className="bg-slate-100 px-6 py-3 border-b border-slate-200">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
              <span className={`flex items-center gap-1.5 ${step >= 1 ? 'text-teal-700 font-bold' : ''}`}>
                <span className="w-5 h-5 rounded-full bg-teal-600 text-white text-[10px] flex items-center justify-center">1</span> Address
              </span>
              <span className="text-slate-300">───</span>
              <span className={`flex items-center gap-1.5 ${step >= 2 ? 'text-teal-700 font-bold' : ''}`}>
                <span className={`w-5 h-5 rounded-full ${step >= 2 ? 'bg-teal-600 text-white' : 'bg-slate-300 text-slate-600'} text-[10px] flex items-center justify-center`}>2</span> Delivery
              </span>
              <span className="text-slate-300">───</span>
              <span className={`flex items-center gap-1.5 ${step >= 3 ? 'text-teal-700 font-bold' : ''}`}>
                <span className={`w-5 h-5 rounded-full ${step >= 3 ? 'bg-teal-600 text-white' : 'bg-slate-300 text-slate-600'} text-[10px] flex items-center justify-center`}>3</span> Payment
              </span>
            </div>
          </div>
        )}

        {/* Step Body */}
        <div className="p-6">

          {/* STEP 1: Address */}
          {step === 1 && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-teal-600" /> Delivery Address Details
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Full Name</label>
                  <input
                    type="text"
                    value={address.fullName}
                    onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Mobile Number</label>
                  <input
                    type="text"
                    value={address.phone}
                    onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">House / Flat / Street Address</label>
                  <input
                    type="text"
                    value={address.street}
                    onChange={(e) => setAddress({ ...address, street: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">City</label>
                  <input
                    type="text"
                    value={address.city}
                    onChange={(e) => setAddress({ ...address, city: e.target.value })}
                    className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">State</label>
                    <input
                      type="text"
                      value={address.state}
                      onChange={(e) => setAddress({ ...address, state: e.target.value })}
                      className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">PIN Code</label>
                    <input
                      type="text"
                      value={address.pincode}
                      onChange={(e) => setAddress({ ...address, pincode: e.target.value })}
                      className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={() => setStep(2)}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 mt-4"
              >
                Proceed to Delivery Options <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 2: Delivery */}
          {step === 2 && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-teal-600" /> Choose Delivery Option
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div
                  onClick={() => setDeliveryType('EXPRESS')}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                    deliveryType === 'EXPRESS'
                      ? 'border-teal-500 bg-teal-50/60 shadow-md ring-2 ring-teal-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="bg-teal-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded flex items-center gap-1">
                      <Zap className="w-3 h-3" /> EXPRESS DELIVERY
                    </span>
                    <span className="text-xs font-bold text-teal-700">₹49</span>
                  </div>
                  <h5 className="text-sm font-bold text-slate-900">24 – 48 Hours Express</h5>
                  <p className="text-xs text-slate-500 mt-1">Priority dispatch directly from nearest smart fulfillment center.</p>
                </div>

                <div
                  onClick={() => setDeliveryType('STANDARD')}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                    deliveryType === 'STANDARD'
                      ? 'border-teal-500 bg-teal-50/60 shadow-md ring-2 ring-teal-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="bg-slate-200 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded">
                      STANDARD DELIVERY
                    </span>
                    <span className="text-xs font-bold text-slate-700">{subtotal >= 99 ? 'FREE' : '₹40'}</span>
                  </div>
                  <h5 className="text-sm font-bold text-slate-900">2 – 5 Business Days</h5>
                  <p className="text-xs text-slate-500 mt-1">Standard logistics delivery. Free for orders above ₹99.</p>
                </div>

              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-semibold rounded-xl flex items-center gap-1"
                >
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>

                <button
                  onClick={() => setStep(3)}
                  className="py-3 px-6 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                >
                  Proceed to Payment <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Payment */}
          {step === 3 && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-teal-600" /> Select Payment Method
              </h4>

              <div className="space-y-2">
                {[
                  { id: 'UPI', label: 'UPI (Google Pay, PhonePe, Paytm)', desc: 'Instant 1-click UPI sandbox payment' },
                  { id: 'COD', label: 'Cash on Delivery (COD)', desc: 'Pay cash or UPI upon delivery (+ ₹20 COD Fee)' },
                  { id: 'CREDIT_CARD', label: 'Credit / Debit Card', desc: 'Secure Visa, Mastercard, RuPay' },
                  { id: 'NET_BANKING', label: 'Net Banking', desc: 'All major Indian nationalized banks' }
                ].map((opt) => (
                  <div
                    key={opt.id}
                    onClick={() => setPaymentMethod(opt.id as PaymentMethod)}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                      paymentMethod === opt.id
                        ? 'border-teal-500 bg-teal-50/60 shadow-sm ring-1 ring-teal-500'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${paymentMethod === opt.id ? 'border-teal-600 bg-teal-600' : 'border-slate-300'}`}>
                        {paymentMethod === opt.id && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-slate-900">{opt.label}</h5>
                        <p className="text-[11px] text-slate-500">{opt.desc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary Box */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600"><span>Items Subtotal:</span><span>₹{subtotal.toFixed(2)}</span></div>
                {discountAmount > 0 && <div className="flex justify-between text-teal-700"><span>Discount:</span><span>-₹{discountAmount}</span></div>}
                <div className="flex justify-between text-slate-600"><span>Delivery Charge ({deliveryType}):</span><span>₹{deliveryCharge}</span></div>
                {codFee > 0 && <div className="flex justify-between text-amber-700"><span>COD Fee:</span><span>+₹{codFee}</span></div>}
                <div className="flex justify-between font-bold text-slate-900 pt-2 border-t border-slate-200 text-sm">
                  <span>Total Amount Payable:</span>
                  <span className="text-teal-700">₹{totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setStep(2)}
                  className="px-4 py-2.5 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-semibold rounded-xl flex items-center gap-1"
                >
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>

                <button
                  disabled={isProcessing}
                  onClick={handlePlaceOrder}
                  className="py-3 px-6 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-teal-500/20 transition flex items-center gap-2"
                >
                  {isProcessing ? (
                    <span>Processing Order...</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" /> Confirm & Place Order (₹{totalAmount.toFixed(2)})
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

          {/* STEP 4: Order Confirmation */}
          {step === 4 && completedOrder && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle className="w-10 h-10 animate-bounce" />
              </div>

              <div>
                <h3 className="text-xl font-black text-slate-900">Order Placed Successfully!</h3>
                <p className="text-xs text-slate-500 mt-1">Order ID: <span className="font-bold text-teal-700">{completedOrder.orderId}</span></p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between"><span className="text-slate-500">Estimated Delivery:</span><span className="font-bold text-slate-900">{completedOrder.estimatedDeliveryDate}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Payment Method:</span><span className="font-semibold text-slate-800">{completedOrder.paymentMethod}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Delivery Type:</span><span className="font-semibold text-teal-700">{completedOrder.deliveryType}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Total Paid:</span><span className="font-bold text-slate-900">₹{completedOrder.totalAmount.toFixed(2)}</span></div>
              </div>

              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={() => {
                    onClose();
                    onOrderComplete(completedOrder);
                  }}
                  className="py-3 px-6 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition"
                >
                  Track Order Status
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
