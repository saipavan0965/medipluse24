import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Mail, Phone, Lock, User, ArrowRight, ShieldCheck, HeartPulse, Sparkles, CheckCircle2 } from 'lucide-react';

interface AuthPageProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onClose, onSuccess }) => {
  const { login, loginWithMobile, setRole } = useAuth();

  const [authMode, setAuthMode] = useState<'EMAIL' | 'MOBILE' | 'ADMIN'>('EMAIL');
  const [isSignup, setIsSignup] = useState(false);

  // Email form
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  // Mobile OTP form
  const [mobile, setMobile] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    login(email, authMode === 'ADMIN' ? 'ADMIN' : 'CUSTOMER', name);
    if (authMode === 'ADMIN') {
      setRole('ADMIN');
    }
    onSuccess();
    onClose();
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile.length >= 10) {
      setOtpSent(true);
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length >= 4) {
      loginWithMobile(mobile);
      onSuccess();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white text-center space-y-2 relative">
          <div className="w-12 h-12 rounded-2xl bg-teal-500 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-teal-500/30">
            <HeartPulse className="w-6 h-6 animate-pulse" />
          </div>
          <h2 className="text-xl font-bold font-display">Welcome to MediPulse AI</h2>
          <p className="text-xs text-slate-300">Sign in to access pharmacy shopping & order history</p>

          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800"
          >
            ✕
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="bg-slate-100 p-1 flex items-center gap-1 text-xs font-semibold text-slate-600 border-b border-slate-200">
          <button
            onClick={() => { setAuthMode('EMAIL'); setOtpSent(false); }}
            className={`flex-1 py-2 text-center rounded-xl transition ${authMode === 'EMAIL' ? 'bg-white text-teal-700 font-bold shadow-sm' : 'hover:text-slate-900'}`}
          >
            Email Login
          </button>
          <button
            onClick={() => { setAuthMode('MOBILE'); setOtpSent(false); }}
            className={`flex-1 py-2 text-center rounded-xl transition ${authMode === 'MOBILE' ? 'bg-white text-teal-700 font-bold shadow-sm' : 'hover:text-slate-900'}`}
          >
            Mobile OTP
          </button>
          <button
            onClick={() => { setAuthMode('ADMIN'); setOtpSent(false); }}
            className={`flex-1 py-2 text-center rounded-xl transition ${authMode === 'ADMIN' ? 'bg-indigo-600 text-white font-bold shadow-sm' : 'hover:text-slate-900'}`}
          >
            Admin Login
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          
          {/* EMAIL MODE */}
          {authMode === 'EMAIL' && (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              {isSignup && (
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Full Name</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      placeholder="Dr. Rajesh Sharma"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-50 text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                    />
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Email Address</label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    placeholder="user@medipulse.ai"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-50 text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Password</label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-50 text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded text-teal-600" />
                  <span>Remember me</span>
                </label>
                <button type="button" className="text-teal-700 hover:underline">Forgot password?</button>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center justify-center gap-1.5"
              >
                <span>{isSignup ? 'Create Customer Account' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-[11px] text-center text-slate-500">
                {isSignup ? 'Already have an account?' : "Don't have an account?"}{' '}
                <button type="button" onClick={() => setIsSignup(!isSignup)} className="text-teal-700 font-bold hover:underline">
                  {isSignup ? 'Sign In' : 'Sign Up'}
                </button>
              </p>
            </form>
          )}

          {/* MOBILE OTP MODE */}
          {authMode === 'MOBILE' && (
            <div className="space-y-4">
              {!otpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Mobile Number</label>
                    <div className="relative">
                      <input
                        type="tel"
                        required
                        placeholder="+91 98765 43210"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        className="w-full bg-slate-50 text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                      />
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition"
                  >
                    Send One-Time Password (OTP)
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-4">
                  <div className="bg-teal-50 p-3 rounded-xl border border-teal-200 text-xs text-teal-800 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>OTP sent to {mobile}. Enter demo OTP: <strong>8892</strong></span>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Enter 4-Digit OTP</label>
                    <input
                      type="text"
                      maxLength={4}
                      placeholder="8892"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      className="w-full bg-slate-50 text-center text-base font-black font-mono tracking-widest p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-md transition"
                  >
                    Verify OTP & Login
                  </button>
                </form>
              )}
            </div>
          )}

          {/* ADMIN MODE */}
          {authMode === 'ADMIN' && (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-200 text-xs text-indigo-900 font-medium">
                Admin Authentication Console: Access inventory dashboard, POS counter, and AI reorder recommendations.
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Admin Email</label>
                <input
                  type="email"
                  required
                  defaultValue="admin@medipulse.ai"
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Password</label>
                <input
                  type="password"
                  required
                  defaultValue="admin123"
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" /> Enter Admin Console
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
