import React from 'react';
import { Medicine } from '../../types';
import { useCart } from '../../context/CartContext';
import { ShoppingBag, Star, AlertCircle, ShieldAlert, CheckCircle2, Clock, Zap } from 'lucide-react';

interface MedicineCardProps {
  medicine: Medicine;
  onViewDetails: (medicine: Medicine) => void;
  onBuyNow: (medicine: Medicine) => void;
}

export const MedicineCard: React.FC<MedicineCardProps> = ({ medicine, onViewDetails, onBuyNow }) => {
  const { addToCart } = useCart();

  const isLowStock = medicine.stockQuantity > 0 && medicine.stockQuantity <= medicine.reorderLevel;
  const isOutOfStock = medicine.stockQuantity === 0;

  const fallbackImage = 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80';

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group">
      
      {/* Card Header & Image Container */}
      <div className="relative bg-slate-50 p-4 border-b border-slate-100 flex items-center justify-center min-h-[190px]">
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 z-10">
          {medicine.discountPercentage > 0 && (
            <span className="bg-red-500 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-md shadow-sm">
              {medicine.discountPercentage}% OFF
            </span>
          )}
          {medicine.prescriptionRequired && (
            <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-1">
              <ShieldAlert className="w-3 h-3 text-amber-600" /> Rx Required
            </span>
          )}
        </div>

        {/* Stock Status Pill */}
        <div className="absolute top-3 right-3 z-10">
          {isOutOfStock ? (
            <span className="bg-slate-800 text-white text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-red-400" /> Out of Stock
            </span>
          ) : isLowStock ? (
            <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
              <Clock className="w-3 h-3" /> Only {medicine.stockQuantity} Left
            </span>
          ) : (
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-200 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> In Stock
            </span>
          )}
        </div>

        {/* Medicine Product Image */}
        <img
          src={medicine.image}
          onError={(e) => { e.currentTarget.src = fallbackImage; }}
          alt={medicine.name}
          className="h-36 w-36 object-contain group-hover:scale-105 transition-transform duration-300 cursor-pointer"
          onClick={() => onViewDetails(medicine)}
          loading="lazy"
        />
      </div>

      {/* Card Content Body */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
            <span className="font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-100">{medicine.category}</span>
            <span className="flex items-center gap-1 text-slate-700 font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {medicine.rating}
            </span>
          </div>

          <h3
            onClick={() => onViewDetails(medicine)}
            className="text-sm font-bold text-slate-900 group-hover:text-teal-600 transition line-clamp-1 cursor-pointer"
            title={medicine.name}
          >
            {medicine.name}
          </h3>

          <p className="text-[11px] text-slate-500 line-clamp-1 font-medium mt-0.5">By {medicine.brand}</p>
          
          <p className="text-xs text-slate-600 line-clamp-2 mt-2 leading-relaxed">
            {medicine.description}
          </p>
        </div>

        {/* Pricing & Actions */}
        <div className="pt-2 border-t border-slate-100 space-y-3">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-lg font-extrabold text-slate-900 font-display">₹{medicine.finalPrice.toFixed(2)}</span>
              {medicine.discountPercentage > 0 && (
                <span className="text-xs text-slate-400 line-through ml-2 font-medium">₹{medicine.price.toFixed(2)}</span>
              )}
            </div>
            <span className="text-[10px] text-slate-400 font-medium">Exp: {medicine.expiryDate}</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              disabled={isOutOfStock}
              onClick={() => addToCart(medicine)}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                isOutOfStock
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 active:scale-95'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" /> Cart
            </button>

            <button
              disabled={isOutOfStock}
              onClick={() => onBuyNow(medicine)}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                isOutOfStock
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-teal-600 hover:bg-teal-700 text-white shadow-sm shadow-teal-500/20 active:scale-95'
              }`}
            >
              <Zap className="w-3.5 h-3.5" /> Buy Now
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
