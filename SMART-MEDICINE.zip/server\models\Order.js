import mongoose from 'mongoose';

const orderItemSchema = new mongoose.Schema({
  productId: String,
  name: String,
  brand: String,
  price: Number,
  discountPercentage: Number,
  finalPrice: Number,
  quantity: Number,
  prescriptionRequired: Boolean
});

const orderSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true },
  userName: { type: String, required: true },
  userPhone: { type: String, required: true },
  address: {
    fullName: String,
    phone: String,
    street: String,
    city: String,
    state: String,
    pincode: String
  },
  items: [orderItemSchema],
  subtotal: Number,
  deliveryCharge: Number,
  codFee: Number,
  discountAmount: Number,
  totalAmount: Number,
  paymentMethod: String,
  paymentStatus: { type: String, default: 'PAID' },
  deliveryType: { type: String, default: 'EXPRESS' },
  orderStatus: { type: String, default: 'Confirmed' },
  estimatedDeliveryDate: String
}, { timestamps: true });

export const OrderModel = mongoose.models.Order || mongoose.model('Order', orderSchema);
