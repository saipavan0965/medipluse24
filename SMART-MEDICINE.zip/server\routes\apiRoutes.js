import express from 'express';
import { MedicineModel } from '../models/Medicine.js';
import { OrderModel } from '../models/Order.js';
import { INITIAL_MEDICINES, INITIAL_HEALTHCARE_PRODUCTS, INITIAL_SUPPLIERS, INITIAL_OFFERS, INITIAL_HEALTH_TIPS, INITIAL_PURCHASE_ORDERS, INITIAL_ORDERS, INITIAL_SALES } from '../data/serverMockData.js';

const router = express.Router();

// Memory store for server fallback state
let memoryMedicines = [...INITIAL_MEDICINES];
let memoryOrders = [...INITIAL_ORDERS];
let memorySales = [...INITIAL_SALES];
let memoryPOs = [...INITIAL_PURCHASE_ORDERS];
let memorySubscribers = ['customer1@gmail.com', 'health.user@gmail.com'];

// 1. Medicines & Inventory APIs
router.get('/medicines', async (req, res) => {
  try {
    const meds = await MedicineModel.find();
    if (meds.length > 0) return res.json(meds);
  } catch (e) {}
  res.json(memoryMedicines);
});

router.post('/medicines', async (req, res) => {
  const newMed = { ...req.body, id: `med-${Date.now()}` };
  memoryMedicines.unshift(newMed);
  try {
    const created = await MedicineModel.create(newMed);
    return res.status(201).json(created);
  } catch (e) {
    res.status(201).json(newMed);
  }
});

router.put('/medicines/:id', async (req, res) => {
  const id = req.params.id;
  memoryMedicines = memoryMedicines.map(m => m.id === id || m.medicineId === id ? { ...m, ...req.body } : m);
  try {
    await MedicineModel.findOneAndUpdate({ medicineId: id }, req.body);
  } catch (e) {}
  res.json({ success: true });
});

router.delete('/medicines/:id', async (req, res) => {
  const id = req.params.id;
  memoryMedicines = memoryMedicines.filter(m => m.id !== id && m.medicineId !== id);
  try {
    await MedicineModel.findOneAndDelete({ medicineId: id });
  } catch (e) {}
  res.json({ success: true });
});

// 2. Healthcare Products
router.get('/products', (req, res) => {
  res.json(INITIAL_HEALTHCARE_PRODUCTS);
});

// 3. Suppliers & Purchase Orders
router.get('/suppliers', (req, res) => {
  res.json(INITIAL_SUPPLIERS);
});

router.get('/purchase-orders', (req, res) => {
  res.json(memoryPOs);
});

router.post('/purchase-orders', (req, res) => {
  const newPO = { ...req.body, id: `po-${Date.now()}` };
  memoryPOs.unshift(newPO);
  res.status(201).json(newPO);
});

router.put('/purchase-orders/:id', (req, res) => {
  const id = req.params.id;
  memoryPOs = memoryPOs.map(p => p.id === id ? { ...p, ...req.body } : p);
  res.json({ success: true });
});

// 4. Orders
router.get('/orders', async (req, res) => {
  try {
    const orders = await OrderModel.find().sort({ createdAt: -1 });
    if (orders.length > 0) return res.json(orders);
  } catch (e) {}
  res.json(memoryOrders);
});

router.post('/orders', async (req, res) => {
  const newOrder = { ...req.body, id: `ord-${Date.now()}` };
  memoryOrders.unshift(newOrder);
  try {
    const created = await OrderModel.create(newOrder);
    return res.status(201).json(created);
  } catch (e) {
    res.status(201).json(newOrder);
  }
});

// 5. Sales & POS
router.get('/sales', (req, res) => {
  res.json(memorySales);
});

router.post('/sales', (req, res) => {
  const newSale = { ...req.body, id: `sale-${Date.now()}` };
  memorySales.unshift(newSale);
  res.status(201).json(newSale);
});

// 6. Offers & Health Tips
router.get('/offers', (req, res) => {
  res.json(INITIAL_OFFERS);
});

router.get('/health-tips', (req, res) => {
  res.json(INITIAL_HEALTH_TIPS);
});

// 7. Subscriptions
router.get('/subscriptions', (req, res) => {
  res.json(memorySubscribers);
});

router.post('/subscriptions', (req, res) => {
  const { email } = req.body;
  if (email && !memorySubscribers.includes(email)) {
    memorySubscribers.push(email);
  }
  res.json({ success: true, message: 'Subscribed successfully' });
});

export default router;
