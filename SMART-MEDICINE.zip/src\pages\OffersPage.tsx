import React from 'react';
import { Offer } from '../types';
import { Tag, Clock, ArrowRight, ShieldCheck, Copy, Check } from 'lucide-react';

interface OffersPageProps {
  offers: Offer[];
  onNavigate: (page: string) => void;
}

export const OffersPage: React.FC<OffersPageProps> = ({ offers, onNavigate }) => {
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-100 text-red-800 text-xs font-bold mb-2">
          <Tag className="w-4 h-4 text-red-600" /> Special Deals & Discounts
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Active Offers & Exclusive Coupon Codes</h1>
        <p className="text-xs text-slate-500">Copy coupon code and paste at checkout to redeem savings</p>
      </div>

      {/* Offers Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {offers.map((off) => (
          <div key={off.id} className="bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group">
            
            <div className="bg-gradient-to-r from-teal-600 to-teal-800 text-white p-6 relative">
              <span className="bg-white/20 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded uppercase tracking-wider">
                Limited Time Offer
              </span>
              <h3 className="text-xl font-bold mt-3">{off.title}</h3>
              <p className="text-xs text-teal-100 mt-1">{off.description}</p>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-slate-400" /> Valid until {off.validUntil}</span>
                <span className="font-bold text-teal-700">{off.discountPercent}% Discount</span>
              </div>

              {/* Coupon Box */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-dashed border-slate-300 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Promo Code</span>
                  <span className="text-sm font-black font-mono text-slate-900 tracking-wider">{off.code}</span>
                </div>
                <button
                  onClick={() => handleCopy(off.code)}
                  className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1"
                >
                  {copiedCode === off.code ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedCode === off.code ? 'Copied' : 'Copy Code'}
                </button>
              </div>

              <button
                onClick={() => onNavigate('medicines')}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-2"
              >
                Shop Eligible Products <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
