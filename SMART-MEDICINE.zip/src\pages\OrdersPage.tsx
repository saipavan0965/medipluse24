import React, { useState } from 'react';
import { Order, OrderStatus } from '../types';
import { ShoppingBag, Truck, CheckCircle2, Clock, MapPin, Package, ShieldCheck, ChevronRight } from 'lucide-react';

interface OrdersPageProps {
  orders: Order[];
}

export const OrdersPage: React.FC<OrdersPageProps> = ({ orders }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0] || null);

  const statuses: OrderStatus[] = ['Order Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

  const getStatusStepIndex = (status: OrderStatus) => {
    return statuses.indexOf(status);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold mb-2">
          <Truck className="w-4 h-4 text-teal-600" /> Order History & Live Delivery Tracking
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">My Pharmacy Orders</h1>
        <p className="text-xs text-slate-500">Track express doorstep delivery and review past order invoices</p>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No orders placed yet</h3>
          <p className="text-xs text-slate-500">When you place an order, your tracking timeline and invoice details will appear here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Orders List (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Past & Active Orders ({orders.length})</h3>
            <div className="space-y-3">
              {orders.map((ord) => {
                const isSelected = selectedOrder?.id === ord.id || selectedOrder?.orderId === ord.orderId;
                return (
                  <div
                    key={ord.id}
                    onClick={() => setSelectedOrder(ord)}
                    className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                      isSelected
                        ? 'border-teal-500 bg-teal-50/60 shadow-md ring-2 ring-teal-500/20'
                        : 'bg-white hover:border-slate-300 border-slate-200'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{ord.orderId}</span>
                        <span className="bg-teal-100 text-teal-800 text-[10px] font-extrabold px-2 py-0.5 rounded">
                          {ord.deliveryType}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">{ord.items.length} items • ₹{ord.totalAmount.toFixed(2)}</p>
                      <p className="text-[10px] text-slate-400">Date: {ord.createdAt}</p>
                    </div>

                    <div className="text-right space-y-1">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900 text-white">
                        {ord.orderStatus}
                      </span>
                      <ChevronRight className="w-4 h-4 text-slate-400 ml-auto" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Detailed Tracking Timeline (7 cols) */}
          {selectedOrder && (
            <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
              
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Order #{selectedOrder.orderId}</h3>
                  <p className="text-xs text-slate-500">Placed on {selectedOrder.createdAt}</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-teal-700 block">Est. Delivery: {selectedOrder.estimatedDeliveryDate}</span>
                  <span className="text-[10px] text-slate-400">Payment: {selectedOrder.paymentMethod}</span>
                </div>
              </div>

              {/* Order Status Progress Bar */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-teal-600" /> Live Delivery Progress
                </h4>

                <div className="grid grid-cols-6 gap-1 relative text-center">
                  {statuses.map((st, idx) => {
                    const currentIdx = getStatusStepIndex(selectedOrder.orderStatus);
                    const isCompleted = idx <= currentIdx;
                    return (
                      <div key={st} className="space-y-2">
                        <div className={`w-7 h-7 rounded-full mx-auto flex items-center justify-center text-xs font-bold transition ${
                          isCompleted ? 'bg-teal-600 text-white shadow-sm' : 'bg-slate-200 text-slate-400'
                        }`}>
                          {idx + 1}
                        </div>
                        <span className={`text-[9px] block font-semibold leading-tight ${isCompleted ? 'text-slate-900 font-bold' : 'text-slate-400'}`}>
                          {st}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Address Box */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1 text-xs text-slate-600">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1">Delivery Destination</h4>
                <p className="font-bold text-slate-800">{selectedOrder.address.fullName} ({selectedOrder.address.phone})</p>
                <p>{selectedOrder.address.street}, {selectedOrder.address.city}, {selectedOrder.address.state} - {selectedOrder.address.pincode}</p>
              </div>

              {/* Items List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Ordered Medicines ({selectedOrder.items.length})</h4>
                <div className="divide-y divide-slate-100">
                  {selectedOrder.items.map((item) => (
                    <div key={item.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <img src={item.image} alt={item.name} className="w-10 h-10 object-contain bg-slate-50 rounded-lg p-1" />
                        <div>
                          <h5 className="font-bold text-slate-900">{item.name}</h5>
                          <span className="text-[10px] text-slate-400">{item.brand} • {item.quantity} units</span>
                        </div>
                      </div>
                      <span className="font-bold text-slate-900">₹{(item.finalPrice * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order Total Box */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-1 text-slate-600">
                <div className="flex justify-between"><span>Subtotal:</span><span>₹{selectedOrder.subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Delivery Fee ({selectedOrder.deliveryType}):</span><span>₹{selectedOrder.deliveryCharge}</span></div>
                {selectedOrder.codFee > 0 && <div className="flex justify-between"><span>COD Fee:</span><span>₹{selectedOrder.codFee}</span></div>}
                <div className="flex justify-between font-black text-slate-900 text-sm pt-2 border-t border-slate-200">
                  <span>Grand Total Amount:</span>
                  <span className="text-teal-700">₹{selectedOrder.totalAmount.toFixed(2)}</span>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
};
