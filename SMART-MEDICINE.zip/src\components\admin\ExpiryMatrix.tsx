import React, { useState } from 'react';
import { ExpiryRiskItem } from '../../types';
import { AlertTriangle, Clock, ShieldAlert, CheckCircle2, ArrowUpDown, Filter, Tag } from 'lucide-react';

interface ExpiryMatrixProps {
  expiryRisks: ExpiryRiskItem[];
}

export const ExpiryMatrix: React.FC<ExpiryMatrixProps> = ({ expiryRisks }) => {
  const [filterTier, setFilterTier] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'days' | 'qty' | 'risk'>('days');

  const filtered = expiryRisks.filter(r => {
    if (filterTier === 'ALL') return true;
    return r.riskTier === filterTier;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'days') return a.daysRemaining - b.daysRemaining;
    if (sortBy === 'qty') return b.quantity - a.quantity;
    return a.riskTier.localeCompare(b.riskTier);
  });

  const counts = {
    NORMAL: expiryRisks.filter(r => r.riskTier === 'NORMAL').length,
    NEAR_EXPIRY: expiryRisks.filter(r => r.riskTier === 'NEAR_EXPIRY').length,
    URGENT: expiryRisks.filter(r => r.riskTier === 'URGENT').length,
    EXPIRED: expiryRisks.filter(r => r.riskTier === 'EXPIRED').length,
  };

  return (
    <div className="space-y-6">
      
      {/* Category Tiers Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { key: 'EXPIRED', title: 'Expired Stock', count: counts.EXPIRED, desc: 'Passed Expiry Date', color: 'bg-red-50 text-red-700 border-red-200' },
          { key: 'URGENT', title: 'Urgent (<30 Days)', count: counts.URGENT, desc: 'Critical FEFO Window', color: 'bg-orange-50 text-orange-700 border-orange-200' },
          { key: 'NEAR_EXPIRY', title: 'Near Expiry (<60 Days)', count: counts.NEAR_EXPIRY, desc: 'Promotional Candidate', color: 'bg-amber-50 text-amber-700 border-amber-200' },
          { key: 'NORMAL', title: 'Normal (>60 Days)', count: counts.NORMAL, desc: 'Healthy Shelf Life', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
        ].map((t) => (
          <div
            key={t.key}
            onClick={() => setFilterTier(t.key)}
            className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${t.color} ${
              filterTier === t.key ? 'ring-2 ring-slate-900 shadow-md' : 'opacity-90 hover:opacity-100'
            }`}
          >
            <div>
              <h4 className="text-xs font-extrabold uppercase tracking-wider">{t.title}</h4>
              <p className="text-[10px] opacity-80 mt-0.5">{t.desc}</p>
            </div>
            <div className="text-2xl font-black mt-3 font-display">{t.count} Batches</div>
          </div>
        ))}
      </div>

      {/* Expiry Risk Table Console */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
        
        {/* Controls Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Batch Expiry & Shelf Life Audit Log</h3>
            <p className="text-xs text-slate-500">First-Expiry-First-Out (FEFO) recommendation matrix</p>
          </div>

          <div className="flex items-center gap-3">
            {/* Filter by Tier Dropdown */}
            <div className="flex items-center gap-1.5 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={filterTier}
                onChange={(e) => setFilterTier(e.target.value)}
                className="bg-white text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 font-semibold text-slate-700 focus:outline-none"
              >
                <option value="ALL">All Expiry Tiers</option>
                <option value="EXPIRED">Expired</option>
                <option value="URGENT">Urgent (&lt;30d)</option>
                <option value="NEAR_EXPIRY">Near Expiry (&lt;60d)</option>
                <option value="NORMAL">Normal (&gt;60d)</option>
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white text-xs border border-slate-200 rounded-xl px-2.5 py-1.5 font-semibold text-slate-700 focus:outline-none"
              >
                <option value="days">Earliest Expiry</option>
                <option value="qty">Highest Quantity</option>
                <option value="risk">Risk Tier</option>
              </select>
            </div>
          </div>
        </div>

        {/* Table Body */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Medicine Name</th>
                <th className="py-3 px-4">Batch No</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Stock Qty</th>
                <th className="py-3 px-4">Expiry Date</th>
                <th className="py-3 px-4">Days Left</th>
                <th className="py-3 px-4">Risk Level</th>
                <th className="py-3 px-4 max-w-sm">Recommended Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {sorted.map((item, idx) => {
                let riskBadge = 'bg-emerald-100 text-emerald-800';
                if (item.riskTier === 'EXPIRED') riskBadge = 'bg-red-500 text-white font-extrabold shadow-sm animate-pulse';
                if (item.riskTier === 'URGENT') riskBadge = 'bg-orange-500 text-white font-bold';
                if (item.riskTier === 'NEAR_EXPIRY') riskBadge = 'bg-amber-100 text-amber-900 font-bold border border-amber-200';

                return (
                  <tr key={idx} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">{item.medicineName}</td>
                    <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">{item.batchNumber}</td>
                    <td className="py-3 px-4 text-slate-500">{item.category}</td>
                    <td className="py-3 px-4 font-extrabold text-slate-800">{item.quantity} units</td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{item.expiryDate}</td>
                    
                    <td className="py-3 px-4 font-black">
                      <span className={item.daysRemaining <= 30 ? 'text-red-600' : 'text-slate-700'}>
                        {item.daysRemaining <= 0 ? 'Expired' : `${item.daysRemaining} days`}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`text-[10px] px-2.5 py-1 rounded-md ${riskBadge}`}>
                        {item.riskTier.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-600 text-[11px] leading-relaxed max-w-sm font-medium">
                      {item.recommendedAction}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};
