import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, DeliveryType, PaymentMethod, Medicine, HealthcareProduct } from '../types';

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Medicine | HealthcareProduct, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  deliveryType: DeliveryType;
  setDeliveryType: (type: DeliveryType) => void;
  paymentMethod: PaymentMethod;
  setPaymentMethod: (method: PaymentMethod) => void;
  appliedCoupon: string | null;
  discountAmount: number;
  applyCoupon: (code: string, discountPercent: number) => boolean;
  removeCoupon: () => void;
  subtotal: number;
  deliveryCharge: number;
  codFee: number;
  totalAmount: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('medipulse_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [deliveryType, setDeliveryType] = useState<DeliveryType>('EXPRESS');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponPercent, setCouponPercent] = useState<number>(0);

  useEffect(() => {
    localStorage.setItem('medipulse_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Medicine | HealthcareProduct, qty = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id || item.productId === (product as Medicine).medicineId);
      if (existing) {
        return prev.map(item =>
          item.productId === existing.productId
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      } else {
        const isDevice = 'warranty' in product;
        const newItem: CartItem = {
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          productId: product.id || (product as Medicine).medicineId,
          name: product.name,
          brand: product.brand,
          price: product.price,
          discountPercentage: product.discountPercentage,
          finalPrice: product.finalPrice,
          image: product.image,
          quantity: qty,
          prescriptionRequired: (product as Medicine).prescriptionRequired || false,
          isDevice
        };
        return [...prev, newItem];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => item.productId === productId ? { ...item, quantity } : item)
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
    setCouponPercent(0);
  };

  const applyCoupon = (code: string, discountPercent: number): boolean => {
    if (code.trim().toUpperCase() === 'MONSOON20' || code.trim().toUpperCase() === 'WELCOME15' || code.trim().toUpperCase() === 'DEVICES10') {
      setAppliedCoupon(code.toUpperCase());
      setCouponPercent(discountPercent || 15);
      return true;
    }
    return false;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponPercent(0);
  };

  const subtotal = cart.reduce((sum, item) => sum + item.finalPrice * item.quantity, 0);
  
  // Delivery Fee calculation: Express is ₹49; Standard is ₹40 or FREE above ₹99
  const deliveryCharge = deliveryType === 'EXPRESS' ? 49 : (subtotal >= 99 || subtotal === 0 ? 0 : 40);
  
  // COD Fee calculation: ₹20 if COD selected
  const codFee = paymentMethod === 'COD' && subtotal > 0 ? 20 : 0;
  
  // Coupon Discount
  const discountAmount = Math.round((subtotal * couponPercent) / 100);

  const totalAmount = Math.max(0, subtotal - discountAmount + deliveryCharge + codFee);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        deliveryType,
        setDeliveryType,
        paymentMethod,
        setPaymentMethod,
        appliedCoupon,
        discountAmount,
        applyCoupon,
        removeCoupon,
        subtotal,
        deliveryCharge,
        codFee,
        totalAmount,
        itemCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
