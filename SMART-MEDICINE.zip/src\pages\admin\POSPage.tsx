import React from 'react';
import { useData } from '../../context/DataContext';
import { POSInterface } from '../../components/admin/POSInterface';
import { ShoppingCart } from 'lucide-react';

export const POSPage: React.FC = () => {
  const { medicines } = useData();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Point of Sale (POS) Billing Register</h1>
        <p className="text-xs text-slate-500">Quick medicine lookup, discount calculation, printable invoice generation, and instant stock deduction</p>
      </div>

      <POSInterface medicines={medicines} />
    </div>
  );
};
