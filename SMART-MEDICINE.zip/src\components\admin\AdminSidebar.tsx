import React from 'react';
import { LayoutDashboard, Pill, ShoppingCart, TrendingUp, AlertTriangle, RefreshCw, Users, FileText, Bot, Tag, HeartPulse, Sparkles, BarChart2, Shield, LogOut, ArrowLeft } from 'lucide-react';

interface AdminSidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onSwitchToCustomer: () => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({ currentTab, onSelectTab, onSwitchToCustomer }) => {
  const menuGroups = [
    {
      group: 'Core Operations',
      items: [
        { id: 'admin-dashboard', label: 'Executive Overview', icon: LayoutDashboard },
        { id: 'admin-inventory', label: 'Medicines Inventory', icon: Pill },
        { id: 'admin-pos', label: 'POS & Billing Register', icon: ShoppingCart },
        { id: 'admin-orders', label: 'Customer Orders', icon: FileText }
      ]
    },
    {
      group: 'AI Supply Intelligence',
      items: [
        { id: 'admin-forecast', label: 'AI Demand Forecast', icon: TrendingUp },
        { id: 'admin-reorder', label: 'Smart Re-Order Engine', icon: RefreshCw },
        { id: 'admin-expiry', label: 'Expiry Risk Matrix', icon: AlertTriangle },
        { id: 'admin-ai-assistant', label: 'MediPulse AI Assistant', icon: Bot, highlight: true }
      ]
    },
    {
      group: 'Supply Chain & Content',
      items: [
        { id: 'admin-suppliers', label: 'Suppliers Directory', icon: Users },
        { id: 'admin-pos-orders', label: 'Purchase Orders', icon: FileText },
        { id: 'admin-products', label: 'Healthcare Products', icon: HeartPulse },
        { id: 'admin-offers', label: 'Offers & Promotions', icon: Tag },
        { id: 'admin-subscribers', label: 'Subscribers & Content', icon: Sparkles },
        { id: 'admin-reports', label: 'Reports & Analytics', icon: BarChart2 }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 min-h-screen flex flex-col justify-between border-r border-slate-800 shrink-0">
      
      {/* Brand Header */}
      <div>
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-500 text-slate-950 font-black flex items-center justify-center shadow-md shadow-teal-500/20">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">MediPulse <span className="text-teal-400">Admin</span></h2>
              <p className="text-[10px] text-slate-400 font-medium">Pharmacy Supply Control</p>
            </div>
          </div>
        </div>

        {/* Navigation Menu Links */}
        <div className="p-3 space-y-6 overflow-y-auto max-h-[calc(100vh-140px)]">
          {menuGroups.map((group, idx) => (
            <div key={idx} className="space-y-1">
              <h4 className="px-3 text-[10px] font-extrabold uppercase tracking-wider text-slate-500 mb-1">
                {group.group}
              </h4>
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition ${
                      isActive
                        ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-teal-400 animate-pulse' : 'text-slate-400'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.highlight && !isActive && (
                      <span className="bg-teal-500/20 text-teal-400 text-[9px] font-bold px-1.5 py-0.5 rounded border border-teal-500/30">
                        AI
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Switch to Customer Portal Footer */}
      <div className="p-4 border-t border-slate-800">
        <button
          onClick={onSwitchToCustomer}
          className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-teal-300 hover:text-teal-200 text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 border border-slate-700"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Storefront
        </button>
      </div>

    </aside>
  );
};
