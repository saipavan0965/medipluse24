import { Medicine, HealthcareProduct, Order, Supplier, PurchaseOrder, Offer, HealthTip, Subscriber, SalesTransaction } from '../types';
import { INITIAL_MEDICINES, INITIAL_HEALTHCARE_PRODUCTS, INITIAL_SUPPLIERS, INITIAL_OFFERS, INITIAL_HEALTH_TIPS, INITIAL_PURCHASE_ORDERS, INITIAL_ORDERS, INITIAL_SALES } from './mockData';

const API_BASE_URL = '/api';

/**
 * Backend API Client with Local Fallback Engine
 */
export const ApiService = {
  // Medicines
  getMedicines: async (): Promise<Medicine[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/medicines`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Using local fallback data for medicines');
    }
    const stored = localStorage.getItem('medipulse_medicines');
    return stored ? JSON.parse(stored) : INITIAL_MEDICINES;
  },

  saveMedicines: (medicines: Medicine[]) => {
    localStorage.setItem('medipulse_medicines', JSON.stringify(medicines));
  },

  // Healthcare Products
  getHealthcareProducts: async (): Promise<HealthcareProduct[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/products`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Using local fallback data for products');
    }
    const stored = localStorage.getItem('medipulse_products');
    return stored ? JSON.parse(stored) : INITIAL_HEALTHCARE_PRODUCTS;
  },

  // Suppliers
  getSuppliers: async (): Promise<Supplier[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/suppliers`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Using local fallback data for suppliers');
    }
    const stored = localStorage.getItem('medipulse_suppliers');
    return stored ? JSON.parse(stored) : INITIAL_SUPPLIERS;
  },

  // Purchase Orders
  getPurchaseOrders: async (): Promise<PurchaseOrder[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/purchase-orders`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Using local fallback data for POs');
    }
    const stored = localStorage.getItem('medipulse_pos');
    return stored ? JSON.parse(stored) : INITIAL_PURCHASE_ORDERS;
  },

  savePurchaseOrders: (pos: PurchaseOrder[]) => {
    localStorage.setItem('medipulse_pos', JSON.stringify(pos));
  },

  // Customer Orders
  getOrders: async (): Promise<Order[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/orders`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Using local fallback data for orders');
    }
    const stored = localStorage.getItem('medipulse_orders');
    return stored ? JSON.parse(stored) : INITIAL_ORDERS;
  },

  createOrder: async (order: Order): Promise<Order> => {
    try {
      const res = await fetch(`${API_BASE_URL}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order)
      });
      if (res.ok) return await res.json();
    } catch (e) {
      console.log('Saved order locally');
    }
    const orders = await ApiService.getOrders();
    const updated = [order, ...orders];
    localStorage.setItem('medipulse_orders', JSON.stringify(updated));
    return order;
  },

  // Offers
  getOffers: async (): Promise<Offer[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/offers`);
      if (res.ok) return await res.json();
    } catch (e) {}
    const stored = localStorage.getItem('medipulse_offers');
    return stored ? JSON.parse(stored) : INITIAL_OFFERS;
  },

  // Health Tips
  getHealthTips: async (): Promise<HealthTip[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/health-tips`);
      if (res.ok) return await res.json();
    } catch (e) {}
    return INITIAL_HEALTH_TIPS;
  },

  // Newsletter Subscriptions
  subscribeNewsletter: async (email: string): Promise<boolean> => {
    try {
      await fetch(`${API_BASE_URL}/subscriptions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
    } catch (e) {}
    const stored = JSON.parse(localStorage.getItem('medipulse_subscribers') || '[]');
    if (!stored.includes(email)) {
      stored.push(email);
      localStorage.setItem('medipulse_subscribers', JSON.stringify(stored));
    }
    return true;
  },

  getSubscribers: async (): Promise<string[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/subscriptions`);
      if (res.ok) return await res.json();
    } catch (e) {}
    return JSON.parse(localStorage.getItem('medipulse_subscribers') || '["customer1@gmail.com", "health.user@gmail.com"]');
  },

  // POS / Sales
  getSales: async (): Promise<SalesTransaction[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/sales`);
      if (res.ok) return await res.json();
    } catch (e) {}
    const stored = localStorage.getItem('medipulse_sales');
    return stored ? JSON.parse(stored) : INITIAL_SALES;
  },

  recordSale: async (sale: SalesTransaction): Promise<SalesTransaction> => {
    try {
      await fetch(`${API_BASE_URL}/sales`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sale)
      });
    } catch (e) {}
    const sales = await ApiService.getSales();
    const updated = [sale, ...sales];
    localStorage.setItem('medipulse_sales', JSON.stringify(updated));
    return sale;
  }
};
