import React, { useState } from 'react';
import { DemandForecast } from '../../types';
import { useData } from '../../context/DataContext';
import { CheckCircle2, AlertTriangle, RefreshCw, FilePlus, HelpCircle, Sparkles, Check, X } from 'lucide-react';

interface ReorderTableProps {
  forecasts: DemandForecast[];
}

export const ReorderTable: React.FC<ReorderTableProps> = ({ forecasts }) => {
  const { approveReorderForecast } = useData();
  const [approvedIds, setApprovedIds] = useState<string[]>([]);
  const [rejectedIds, setRejectedIds] = useState<string[]>([]);

  const handleApprove = (forecast: DemandForecast) => {
    approveReorderForecast(forecast);
    setApprovedIds(prev => [...prev, forecast.medicineId]);
  };

  const handleReject = (id: string) => {
    setRejectedIds(prev => [...prev, id]);
  };

  const activeForecasts = forecasts.filter(f => !rejectedIds.includes(f.medicineId));

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
      
      {/* Table Banner */}
      <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">Smart AI Re-Order Recommendations</h3>
          </div>
          <p className="text-xs text-slate-500">Automated inventory replenishment proposals derived from demand velocity & lead times</p>
        </div>

        <div className="bg-teal-100 text-teal-900 text-xs font-bold px-3 py-1 rounded-full border border-teal-200">
          {activeForecasts.filter(f => f.recommendedQuantity > 0).length} Reorders Suggested
        </div>
      </div>

      {/* Recommendations Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
              <th className="py-3 px-4">Medicine SKU</th>
              <th className="py-3 px-4">Current Stock</th>
              <th className="py-3 px-4">7-Day Demand</th>
              <th className="py-3 px-4">Safety Stock</th>
              <th className="py-3 px-4">Reorder Pt</th>
              <th className="py-3 px-4">Suggested Qty</th>
              <th className="py-3 px-4">Priority</th>
              <th className="py-3 px-4">Confidence</th>
              <th className="py-3 px-4 max-w-xs">AI Rationale</th>
              <th className="py-3 px-4 text-center">Action</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {activeForecasts.map((f) => {
              const isApproved = approvedIds.includes(f.medicineId);

              let priorityBadge = 'bg-slate-100 text-slate-700';
              if (f.priority === 'URGENT') priorityBadge = 'bg-red-500 text-white font-extrabold shadow-sm';
              if (f.priority === 'HIGH') priorityBadge = 'bg-amber-500 text-white font-bold';
              if (f.priority === 'MEDIUM') priorityBadge = 'bg-teal-100 text-teal-800 font-bold';

              return (
                <tr key={f.medicineId} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    <div>{f.medicineName}</div>
                    <div className="text-[10px] text-slate-400 font-medium">{f.category}</div>
                  </td>

                  <td className="py-3 px-4 font-extrabold text-slate-800">
                    <span className={f.currentStock < f.reorderPoint ? 'text-amber-600 font-bold' : ''}>
                      {f.currentStock}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-semibold text-slate-700">{f.predictedDemand7Days} units</td>
                  <td className="py-3 px-4 text-slate-500">{f.safetyStock}</td>
                  <td className="py-3 px-4 text-slate-500">{f.reorderPoint}</td>
                  
                  <td className="py-3 px-4 font-black text-teal-700 text-sm">
                    {f.recommendedQuantity > 0 ? `+${f.recommendedQuantity}` : '—'}
                  </td>

                  <td className="py-3 px-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded-md ${priorityBadge}`}>
                      {f.priority}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-bold text-slate-700">
                    <div className="flex items-center gap-1">
                      <span>{f.confidenceScore}%</span>
                    </div>
                  </td>

                  <td className="py-3 px-4 max-w-xs text-slate-600 text-[11px] leading-relaxed">
                    {f.reason}
                  </td>

                  <td className="py-3 px-4 text-center">
                    {isApproved ? (
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-lg inline-flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-600" /> PO Created
                      </span>
                    ) : f.recommendedQuantity > 0 ? (
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleApprove(f)}
                          className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg transition text-[11px] shadow-sm flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" /> Approve
                        </button>

                        <button
                          onClick={() => handleReject(f.medicineId)}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-lg transition text-[11px]"
                          title="Dismiss recommendation"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <span className="text-slate-400 text-[10px]">Optimal</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

    </div>
  );
};
