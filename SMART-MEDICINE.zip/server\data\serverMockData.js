export const INITIAL_MEDICINES = [
  {
    id: 'med-1',
    medicineId: 'MED-1001',
    name: 'Paracetamol 650mg (Dolo-650)',
    brand: 'Micro Labs',
    manufacturer: 'Micro Labs Ltd',
    category: 'Fever & Pain Relief',
    description: 'Effective analgesic and antipyretic medicine for fever reduction, muscle pain, and headache relief.',
    price: 35.00,
    discountPercentage: 10,
    finalPrice: 31.50,
    stockQuantity: 145,
    reorderLevel: 50,
    safetyStock: 30,
    batchNumber: 'BT-2025-08A',
    expiryDate: '2026-11-30',
    supplier: 'MedPharma Distribution',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80',
    prescriptionRequired: false,
    rating: 4.8
  }
];

export const INITIAL_HEALTHCARE_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Omron Automatic Upper Arm Blood Pressure Monitor (HEM-7120)',
    category: 'Blood Pressure Monitors',
    brand: 'Omron',
    description: 'Clinical accuracy blood pressure monitor with cuff wrapping guide.',
    price: 2490.00,
    discountPercentage: 20,
    finalPrice: 1992.00,
    stockQuantity: 42,
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_SUPPLIERS = [
  {
    id: 'sup-1',
    supplierId: 'SUP-101',
    name: 'MedPharma Distribution Pvt Ltd',
    contactPerson: 'Rajesh Kumar',
    email: 'orders@medpharma.com',
    phone: '+91 98765 43210',
    address: 'Plot 45, Pharma City, Hyderabad',
    categories: ['Fever & Pain Relief'],
    leadTimeDays: 2,
    moq: 50,
    rating: 4.9
  }
];

export const INITIAL_OFFERS = [
  {
    id: 'off-1',
    title: 'Monsoon Seasonal Health Offer',
    code: 'MONSOON20',
    discountPercent: 20,
    description: 'Get 20% OFF on all Cold, Cough & Respiratory Care.',
    validUntil: '2026-09-30',
    isActive: true
  }
];

export const INITIAL_HEALTH_TIPS = [
  {
    id: 'tip-1',
    title: '5 Simple Ways to Stay Hydrated Every Day',
    category: 'Hydration',
    shortDescription: 'Discover optimal daily fluid intake tips to maintain energy, kidney health, and body temperature balance.',
    content: 'Proper hydration is crucial for cardiovascular efficiency and cellular metabolism. Aim for 2.5 to 3 liters of water daily.',
    image: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=800&auto=format&fit=crop&q=80',
    readTime: '3 min read',
    author: 'Dr. Ananya Sharma, MD',
    date: '2026-08-10'
  },
  {
    id: 'tip-2',
    title: 'Healthy Habits & Immunity Boost During Seasonal Changes',
    category: 'Seasonal Health',
    shortDescription: 'Essential precautions against viral fever, seasonal flu, and respiratory allergens as weather shifts.',
    content: 'Seasonal weather shifts frequently bring sharp spikes in viral infections. Fortify your immune defenses with daily Vitamin C and Zinc.',
    image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    author: 'MediPulse Medical Advisory Team',
    date: '2026-08-14'
  },
  {
    id: 'tip-3',
    title: 'Safe Medicine Storage Tips at Home',
    category: 'Preventive Health',
    shortDescription: 'How to protect heat-sensitive medicines, monitor expiration dates, and prevent accidental child ingestion.',
    content: 'Always store medicines in a cool, dry place away from direct sunlight and bathroom humidity. Insulin requires refrigeration (2°C - 8°C).',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80',
    readTime: '3 min read',
    author: 'Pharmacist R. Verma, B.Pharm',
    date: '2026-08-18'
  },
  {
    id: 'tip-4',
    title: 'Essential Nutrition Guide for Active Adults',
    category: 'Nutrition',
    shortDescription: 'Balanced macronutrient strategies, dietary fiber, and vitamin absorption tips for daily vitality.',
    content: 'A balanced diet rich in leafy greens, lean proteins, whole grains, and healthy Omega-3 fats fuels brain function and cellular repair.',
    image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=800&auto=format&fit=crop&q=80',
    readTime: '5 min read',
    author: 'Dr. Priya Nair, Clinical Nutritionist',
    date: '2026-08-15'
  },
  {
    id: 'tip-5',
    title: 'Elderly Care: Managing Chronic Conditions & Pill Schedules',
    category: 'Elderly Care',
    shortDescription: 'Practical advice for senior citizens managing hypertension, diabetes, and daily dosage tracking.',
    content: 'Senior health care requires consistent pill timing, regular blood pressure monitoring, and gentle low-impact exercises.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    author: 'Dr. S. K. Gupta, Geriatric Specialist',
    date: '2026-08-12'
  },
  {
    id: 'tip-6',
    title: 'Importance of 7-8 Hours Restorative Sleep',
    category: 'Sleep',
    shortDescription: 'How deep sleep cycles regulate cortisol hormones, boost antibody production, and sharpen focus.',
    content: 'Quality sleep is essential for immune cell regeneration. Maintain a consistent sleep schedule and keep your bedroom cool and quiet.',
    image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=800&auto=format&fit=crop&q=80',
    readTime: '3 min read',
    author: 'MediPulse Wellness Team',
    date: '2026-08-11'
  },
  {
    id: 'tip-7',
    title: 'Child Care: First Aid Basics for Parents & Caregivers',
    category: 'Child Care',
    shortDescription: 'Essential steps for handling minor scratches, seasonal allergies, and fever in children.',
    content: 'Keep a pediatric first-aid kit stocked with digital thermometers, antiseptic wipes, pediatric ORS, and band-aids.',
    image: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    author: 'Dr. Meera Menon, Pediatrician',
    date: '2026-08-09'
  },
  {
    id: 'tip-8',
    title: 'Daily 30-Minute Exercise Routine for Heart Health',
    category: 'Exercise',
    shortDescription: 'Aerobic walking, stretching, and resistance exercises to strengthen cardiovascular endurance.',
    content: 'Moderate physical exercise for 30 minutes daily improves insulin sensitivity, lowers resting heart rate, and elevates endorphins.',
    image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&auto=format&fit=crop&q=80',
    readTime: '4 min read',
    author: 'Coach Vikram Singh, Physiotherapist',
    date: '2026-08-08'
  }
];

export const INITIAL_PURCHASE_ORDERS = [];
export const INITIAL_ORDERS = [];
export const INITIAL_SALES = [];
