import React, { useState } from 'react';
import { HealthTip } from '../types';
import { FileText, Clock, User, ArrowLeft, Search, ShieldCheck } from 'lucide-react';

interface HealthTipsPageProps {
  tips: HealthTip[];
}

export const HealthTipsPage: React.FC<HealthTipsPageProps> = ({ tips }) => {
  const [selectedTip, setSelectedTip] = useState<HealthTip | null>(null);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  const categories = ['ALL', 'General Wellness', 'Nutrition', 'Exercise', 'Sleep', 'Hydration', 'Seasonal Health', 'Elderly Care', 'Child Care', 'Preventive Health'];

  const fallbackImage = 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80';

  const filteredTips = tips.filter(t => {
    const matchQuery = t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase()) ||
      t.shortDescription.toLowerCase().includes(search.toLowerCase());
    
    const matchCat = selectedCategory === 'ALL' || t.category === selectedCategory;
    return matchQuery && matchCat;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold mb-2">
          <FileText className="w-4 h-4 text-blue-600" /> Educational Healthcare Articles & Guides
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Health Tips & Wellness Guidance</h1>
        <p className="text-xs text-slate-500">General educational advice prepared by MediPulse medical advisory panel</p>
      </div>

      {selectedTip ? (
        /* Full Article Reader View */
        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-md space-y-6 max-w-4xl mx-auto">
          <button
            onClick={() => setSelectedTip(null)}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Articles
          </button>

          <img
            src={selectedTip.image}
            onError={(e) => { e.currentTarget.src = fallbackImage; }}
            alt={selectedTip.title}
            className="w-full h-80 object-cover rounded-2xl shadow-sm"
          />

          <div className="space-y-3">
            <span className="bg-teal-100 text-teal-800 text-xs font-bold px-3 py-1 rounded-full border border-teal-200">
              {selectedTip.category}
            </span>
            <h2 className="text-2xl font-bold text-slate-900">{selectedTip.title}</h2>
            <div className="flex items-center gap-4 text-xs text-slate-500 font-medium">
              <span className="flex items-center gap-1"><User className="w-3.5 h-3.5 text-teal-600" /> {selectedTip.author}</span>
              <span>•</span>
              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-slate-400" /> {selectedTip.readTime}</span>
              <span>•</span>
              <span>{selectedTip.date}</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-sm text-slate-700 leading-relaxed space-y-4 font-sans">
            <p>{selectedTip.content}</p>
          </div>

          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 text-xs text-amber-900">
            <strong>Medical Disclaimer:</strong> Health tips provided here are for general educational purposes only and are not a substitute for professional clinical advice or emergency treatment.
          </div>
        </div>
      ) : (
        /* Articles List Grid with Filters */
        <div className="space-y-6">
          
          <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search health topics (nutrition, sleep, hydration, elderly care...)"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-50 text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-teal-500"
              />
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition ${
                    selectedCategory === cat
                      ? 'bg-teal-600 text-white shadow-sm font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredTips.map((tip) => (
              <div key={tip.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group">
                
                <div className="relative h-48 bg-slate-100 overflow-hidden">
                  <img
                    src={tip.image}
                    onError={(e) => { e.currentTarget.src = fallbackImage; }}
                    alt={tip.title}
                    className="h-48 w-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span className="absolute top-3 left-3 text-[10px] font-bold text-teal-800 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-full shadow-sm border border-teal-100">
                    {tip.category}
                  </span>
                </div>
                
                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-600 transition">{tip.title}</h3>
                    <p className="text-xs text-slate-500 line-clamp-2 mt-1 leading-relaxed">{tip.shortDescription}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {tip.readTime}</span>
                    <button
                      onClick={() => setSelectedTip(tip)}
                      className="text-teal-700 font-bold hover:underline"
                    >
                      Read Full Article
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      )}

    </div>
  );
};
