import React, { useState } from 'react';
import { DemandForecast, ExpiryRiskItem } from '../../types';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, PieChart, Pie, Cell } from 'recharts';

interface DemandChartProps {
  forecasts: DemandForecast[];
  expiryRisks: ExpiryRiskItem[];
}

export const DemandChart: React.FC<DemandChartProps> = ({ forecasts, expiryRisks }) => {
  const [timeframe, setTimeframe] = useState<'7' | '30' | '90'>('30');

  // Daily / Weekly simulated sales & demand curve data
  const salesTrendData = [
    { day: 'Mon', actualSales: 120, predictedDemand: 135, revenue: 14200 },
    { day: 'Tue', actualSales: 165, predictedDemand: 150, revenue: 18900 },
    { day: 'Wed', actualSales: 210, predictedDemand: 190, revenue: 24500 },
    { day: 'Thu', actualSales: 185, predictedDemand: 200, revenue: 21200 },
    { day: 'Fri', actualSales: 240, predictedDemand: 230, revenue: 29800 },
    { day: 'Sat', actualSales: 290, predictedDemand: 280, revenue: 36400 },
    { day: 'Sun', actualSales: 220, predictedDemand: 240, revenue: 27100 },
  ];

  // Category demand comparison
  const categoryDataMap: Record<string, number> = {};
  forecasts.forEach(f => {
    categoryDataMap[f.category] = (categoryDataMap[f.category] || 0) + f.predictedDemand7Days;
  });
  const categoryChartData = Object.keys(categoryDataMap).map(cat => ({
    category: cat.replace(' & ', ' '),
    demand: categoryDataMap[cat]
  }));

  // Expiry risk pie data
  const normalCount = expiryRisks.filter(r => r.riskTier === 'NORMAL').length;
  const nearCount = expiryRisks.filter(r => r.riskTier === 'NEAR_EXPIRY').length;
  const urgentCount = expiryRisks.filter(r => r.riskTier === 'URGENT').length;
  const expiredCount = expiryRisks.filter(r => r.riskTier === 'EXPIRED').length;

  const pieData = [
    { name: 'Normal Stock (>60d)', value: normalCount, color: '#10b981' },
    { name: 'Near Expiry (<60d)', value: nearCount, color: '#f59e0b' },
    { name: 'Urgent Expiry (<30d)', value: urgentCount, color: '#f97316' },
    { name: 'Expired', value: expiredCount, color: '#ef4444' }
  ];

  return (
    <div className="space-y-6">
      
      {/* Timeframe Controls Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h3 className="text-sm font-bold text-slate-900">MediPulse AI Demand Analytics & Trends</h3>
          <p className="text-xs text-slate-500">Real-time stock movement, projected demand vs actual sales</p>
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
          {(['7', '30', '90'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTimeframe(t)}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                timeframe === t ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t} Days
            </button>
          ))}
        </div>
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Actual Sales vs Predicted Demand */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Actual Sales vs AI Predicted Demand ({timeframe}-Day Window)
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={salesTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="actualSales" stroke="#0d9488" strokeWidth={3} name="Actual Unit Sales" />
                <Line type="monotone" dataKey="predictedDemand" stroke="#6366f1" strokeWidth={2} strokeDasharray="4 4" name="AI Demand Forecast" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Projected Demand by Category */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Projected 7-Day Demand by Category
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="category" tick={{ fontSize: 10 }} interval={0} angle={-15} textAnchor="end" />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="demand" fill="#0d9488" radius={[6, 6, 0, 0]} name="Projected Units" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Daily Revenue Performance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Daily Revenue Stream (₹)
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(val) => [`₹${val}`, 'Revenue']} />
                <Bar dataKey="revenue" fill="#3b82f6" radius={[6, 6, 0, 0]} name="Daily Revenue (₹)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Expiry Risk Distribution */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
            Inventory Health & Expiry Risk Matrix
          </h4>
          <div className="h-56 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={4} dataKey="value">
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-400 text-center">First-Expiry-First-Out (FEFO) optimization active</p>
        </div>

      </div>
    </div>
  );
};
