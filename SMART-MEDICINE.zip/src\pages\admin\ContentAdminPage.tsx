import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { ApiService } from '../../services/api';
import { Tag, FileText, Mail, Plus, Trash2, CheckCircle2 } from 'lucide-react';

export const ContentAdminPage: React.FC = () => {
  const { offers, healthTips } = useData();
  const [subscribers, setSubscribers] = useState<string[]>([]);

  useEffect(() => {
    ApiService.getSubscribers().then(res => setSubscribers(res));
  }, []);

  return (
    <div className="space-y-8">
      
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Content, Offers & Subscriber Management</h1>
        <p className="text-xs text-slate-500">Manage promotional offers, educational health articles, and active newsletter subscribers</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Newsletter Subscribers List */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Mail className="w-4 h-4 text-teal-600" /> Newsletter Subscribers ({subscribers.length})
            </h3>
            <span className="text-[10px] text-teal-700 bg-teal-50 px-2 py-0.5 rounded font-bold">Active Subscriptions</span>
          </div>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {subscribers.map((sub, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">{sub}</span>
                <span className="text-[10px] text-slate-400">Subscribed</span>
              </div>
            ))}
          </div>
        </div>

        {/* Active Offers Manager */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Tag className="w-4 h-4 text-teal-600" /> Active Promotional Offers ({offers.length})
            </h3>
          </div>

          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {offers.map((off) => (
              <div key={off.id} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900">{off.title}</span>
                  <span className="text-[10px] font-bold font-mono bg-teal-100 text-teal-800 px-2 py-0.5 rounded">{off.code}</span>
                </div>
                <p className="text-[11px] text-slate-500">{off.description}</p>
                <div className="text-[10px] text-slate-400 pt-1 flex justify-between">
                  <span>Discount: {off.discountPercent}%</span>
                  <span>Valid until: {off.validUntil}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
