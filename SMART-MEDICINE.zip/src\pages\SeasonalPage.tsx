import React from 'react';
import { Medicine } from '../types';
import { MedicineCard } from '../components/customer/MedicineCard';
import { Sun, CloudRain, Snowflake, Flower2, ShieldCheck, Sparkles, TrendingUp } from 'lucide-react';

interface SeasonalPageProps {
  medicines: Medicine[];
  activeSeason: string;
  onSeasonChange: (season: string) => void;
  onViewMedicine: (med: Medicine) => void;
  onBuyNow: (med: Medicine) => void;
}

export const SeasonalPage: React.FC<SeasonalPageProps> = ({
  medicines,
  activeSeason,
  onSeasonChange,
  onViewMedicine,
  onBuyNow
}) => {
  const seasonInfo: Record<string, { title: string; desc: string; precautions: string[]; highDemandCategories: string[]; icon: any; color: string }> = {
    Monsoon: {
      title: 'Monsoon Seasonal Health & Flu Precautions',
      desc: 'High humidity and stagnant water cause frequent mosquito-borne fevers, fungal skin infections, and cold/cough outbreaks.',
      precautions: [
        'Drink boiled or RO-filtered drinking water to avoid gastroenteritis.',
        'Use mosquito repellents and eliminate stagnant water around home premises.',
        'Keep skin dry and apply antifungal powders if prone to sweat rashes.',
        'Ensure daily intake of Vitamin C and Zinc supplements for immune defense.'
      ],
      highDemandCategories: ['Fever & Pain Relief', 'Cold & Cough', 'Respiratory Care', 'Digestive Care'],
      icon: CloudRain,
      color: 'bg-teal-600 text-white'
    },
    Summer: {
      title: 'Summer Heat Care & Dehydration Prevention',
      desc: 'High ambient temperatures increase risk of heatstroke, electrolyte depletion, dehydration, and sun burn.',
      precautions: [
        'Drink at least 3 liters of water or electrolyte solution daily.',
        'Avoid direct sun exposure during peak noon hours (12 PM – 3 PM).',
        'Wear breathable lightweight cotton apparel.',
        'Store all heat-sensitive medicines below 25°C.'
      ],
      highDemandCategories: ['Digestive Care', 'First Aid', 'Vitamins & Supplements', 'Fever & Pain Relief'],
      icon: Sun,
      color: 'bg-amber-500 text-white'
    },
    Winter: {
      title: 'Winter Cold Care & Joint Wellness',
      desc: 'Cold dry winds increase viral flu transmission, asthma exacerbations, dry skin, and arthritic joint pain.',
      precautions: [
        'Keep neck and chest warm during early morning walks.',
        'Moisturize skin with skin barrier lotions daily after bath.',
        'Inhale steam if experiencing nasal block or sinusitis.',
        'Maintain blood pressure monitoring as cold weather constricts blood vessels.'
      ],
      highDemandCategories: ['Cold & Cough', 'Respiratory Care', 'Heart Care', 'Vitamins & Supplements'],
      icon: Snowflake,
      color: 'bg-blue-600 text-white'
    },
    Spring: {
      title: 'Spring Allergen & Pollen Management',
      desc: 'Pollen blooms trigger seasonal allergic rhinitis, sneezing spells, watery eyes, and allergic asthma.',
      precautions: [
        'Wear protective masks outdoor during high pollen count hours.',
        'Wash face and rinse eyes after returning from outdoors.',
        'Keep antihistamine tablets like Cetirizine accessible.',
        'Use air purifiers indoors if susceptible to pollen allergies.'
      ],
      highDemandCategories: ['Cold & Cough', 'Respiratory Care', 'Diabetes Care'],
      icon: Flower2,
      color: 'bg-emerald-600 text-white'
    }
  };

  const currentInfo = seasonInfo[activeSeason] || seasonInfo.Monsoon;
  const SeasonIcon = currentInfo.icon;

  const seasonalMedicines = medicines.filter(m => currentInfo.highDemandCategories.includes(m.category));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold mb-2">
          <Sparkles className="w-4 h-4 text-teal-600" /> AI Seasonal Health & Demand Correlations
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Seasonal Health Guide & Medicine Availability</h1>
        <p className="text-xs text-slate-500">Select a season to view disease precautions and high-demand medicine availability</p>
      </div>

      {/* Season Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {(['Summer', 'Monsoon', 'Winter', 'Spring'] as const).map((season) => {
          const info = seasonInfo[season];
          const Icon = info.icon;
          const isActive = activeSeason === season;
          return (
            <button
              key={season}
              onClick={() => onSeasonChange(season)}
              className={`p-4 rounded-2xl border transition text-left flex items-center justify-between ${
                isActive
                  ? 'bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-teal-500'
                  : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-200'
              }`}
            >
              <div>
                <span className="text-xs font-extrabold uppercase tracking-wider block">{season}</span>
                <span className="text-[10px] text-slate-400 font-medium">Health Forecast</span>
              </div>
              <div className={`p-2 rounded-xl ${isActive ? 'bg-teal-500 text-slate-950' : 'bg-slate-100 text-slate-600'}`}>
                <Icon className="w-5 h-5" />
              </div>
            </button>
          );
        })}
      </div>

      {/* Season Banner Box */}
      <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-100 w-max">
            <SeasonIcon className="w-4 h-4" /> Active Season: {activeSeason}
          </div>
          <h2 className="text-xl font-bold text-slate-900">{currentInfo.title}</h2>
          <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">{currentInfo.desc}</p>

          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">General Precautions</h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
              {currentInfo.precautions.map((p, idx) => (
                <li key={idx} className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="lg:col-span-4 bg-slate-900 text-white p-6 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 text-teal-400 text-xs font-bold">
            <TrendingUp className="w-4 h-4" /> Seasonal Medicine Demand
          </div>
          <p className="text-xs text-slate-300">
            Our AI demand algorithm has boosted inventory allocation for these high-demand categories:
          </p>
          <div className="space-y-1.5 pt-1">
            {currentInfo.highDemandCategories.map((cat) => (
              <div key={cat} className="flex items-center justify-between bg-slate-800 px-3 py-2 rounded-xl text-xs">
                <span className="font-semibold text-white">{cat}</span>
                <span className="text-teal-400 font-bold text-[10px]">Stock Buffer +40%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recommended Seasonal Medicines Catalogue Grid */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900">Recommended Medicines for {activeSeason}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {seasonalMedicines.map((med) => (
            <MedicineCard
              key={med.id}
              medicine={med}
              onViewDetails={onViewMedicine}
              onBuyNow={onBuyNow}
            />
          ))}
        </div>
      </div>

    </div>
  );
};
