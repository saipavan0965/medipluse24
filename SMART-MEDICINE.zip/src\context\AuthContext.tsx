import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';

interface AuthContextType {
  user: User | null;
  role: Role;
  isAuthenticated: boolean;
  login: (email: string, role?: Role, name?: string) => void;
  loginWithMobile: (phone: string) => void;
  logout: () => void;
  setRole: (role: Role) => void;
  updateUser: (updated: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('medipulse_user');
    return saved ? JSON.parse(saved) : {
      id: 'usr-1',
      name: 'Dr. Rajesh Sharma',
      email: 'rajesh.sharma@medipulse.ai',
      phone: '+91 98765 43210',
      role: 'ADMIN',
      addresses: [
        {
          id: 'addr-1',
          fullName: 'Dr. Rajesh Sharma',
          phone: '+91 98765 43210',
          street: '12 Health Plaza, Indiranagar',
          city: 'Bengaluru',
          state: 'Karnataka',
          pincode: '560038',
          isDefault: true
        }
      ]
    };
  });

  const role = user?.role || 'CUSTOMER';

  useEffect(() => {
    if (user) {
      localStorage.setItem('medipulse_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('medipulse_user');
    }
  }, [user]);

  const login = (email: string, roleType: Role = 'CUSTOMER', name: string = 'User') => {
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: name || (email.includes('admin') ? 'Pharmacy Admin' : 'Customer Account'),
      email,
      phone: '+91 98765 43210',
      role: email.toLowerCase().includes('admin') ? 'ADMIN' : roleType,
      addresses: [
        {
          id: `addr-${Date.now()}`,
          fullName: name || 'Customer Account',
          phone: '+91 98765 43210',
          street: '45 Green Park Road',
          city: 'Bengaluru',
          state: 'Karnataka',
          pincode: '560001',
          isDefault: true
        }
      ]
    };
    setUser(newUser);
  };

  const loginWithMobile = (phone: string) => {
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: 'Verified Customer',
      email: `user_${phone.slice(-4)}@medipulse.ai`,
      phone,
      role: 'CUSTOMER',
      addresses: []
    };
    setUser(newUser);
  };

  const logout = () => {
    setUser(null);
  };

  const setRole = (newRole: Role) => {
    if (user) {
      setUser({ ...user, role: newRole });
    } else {
      setUser({
        id: 'usr-guest',
        name: newRole === 'ADMIN' ? 'Pharmacy Admin' : 'Customer',
        email: newRole === 'ADMIN' ? 'admin@medipulse.ai' : 'customer@medipulse.ai',
        role: newRole
      });
    }
  };

  const updateUser = (updated: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...updated });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAuthenticated: !!user,
        login,
        loginWithMobile,
        logout,
        setRole,
        updateUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
